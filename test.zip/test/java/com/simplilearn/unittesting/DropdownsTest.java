/**
 * 
 */
package com.simplilearn.unittesting;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;

import java.util.ArrayList;
import java.util.List;
import org.junit.Test;

/**
 * Parasoft Jtest UTA: Test class for Dropdowns
 *
 * @see com.simplilearn.unittesting.Dropdowns
 * @author IND-Bhavya
 */
public class DropdownsTest {

	/**
	 * Parasoft Jtest UTA: Test for getDropDownName()
	 *
	 * @see com.simplilearn.unittesting.Dropdowns#getDropDownName()
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testGetDropDownName() throws Throwable {
		// Given
		String dropDownName = "dropDownName"; // UTA: default value
		List<DropdownValues> dropDownValues = new ArrayList<DropdownValues>(); // UTA: default value
		DropdownValues item = mock(DropdownValues.class);
		dropDownValues.add(item);
		Dropdowns underTest = new Dropdowns(dropDownName, dropDownValues);

		// When
		String result = underTest.getDropDownName();

		// Then - assertions for result of method getDropDownName()
		assertEquals("dropDownName", result);

		// Then - assertions for this instance of Dropdowns
		assertNotNull(underTest.getDropDownValues());
		assertEquals(1, underTest.getDropDownValues().size());

	}

	/**
	 * Parasoft Jtest UTA: Test for getDropDownValues()
	 *
	 * @see com.simplilearn.unittesting.Dropdowns#getDropDownValues()
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testGetDropDownValues() throws Throwable {
		// Given
		String dropDownName = "dropDownName"; // UTA: default value
		List<DropdownValues> dropDownValues = new ArrayList<DropdownValues>(); // UTA: default value
		DropdownValues item = mock(DropdownValues.class);
		dropDownValues.add(item);
		Dropdowns underTest = new Dropdowns(dropDownName, dropDownValues);

		// When
		List<DropdownValues> result = underTest.getDropDownValues();

		// Then - assertions for result of method getDropDownValues()
		assertNotNull(result);
		assertEquals(1, result.size());

		// Then - assertions for this instance of Dropdowns
		assertEquals("dropDownName", underTest.getDropDownName());

	}

	/**
	 * Parasoft Jtest UTA: Test for setDropDownName(String)
	 *
	 * @see com.simplilearn.unittesting.Dropdowns#setDropDownName(String)
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testSetDropDownName() throws Throwable {
		// Given
		String dropDownName = "dropDownName"; // UTA: default value
		List<DropdownValues> dropDownValues = new ArrayList<DropdownValues>(); // UTA: default value
		DropdownValues item = mock(DropdownValues.class);
		dropDownValues.add(item);
		Dropdowns underTest = new Dropdowns(dropDownName, dropDownValues);

		// When
		String dropDownName2 = "dropDownName2"; // UTA: default value
		underTest.setDropDownName(dropDownName2);

		// Then - assertions for this instance of Dropdowns
		assertEquals("dropDownName2", underTest.getDropDownName());
		assertNotNull(underTest.getDropDownValues());
		assertEquals(1, underTest.getDropDownValues().size());

	}

	/**
	 * Parasoft Jtest UTA: Test for setDropDownValues(List)
	 *
	 * @see com.simplilearn.unittesting.Dropdowns#setDropDownValues(List)
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testSetDropDownValues() throws Throwable {
		// Given
		String dropDownName = "dropDownName"; // UTA: default value
		List<DropdownValues> dropDownValues = new ArrayList<DropdownValues>(); // UTA: default value
		DropdownValues item = mock(DropdownValues.class);
		dropDownValues.add(item);
		Dropdowns underTest = new Dropdowns(dropDownName, dropDownValues);

		// When
		List<DropdownValues> dropDownValues2 = new ArrayList<DropdownValues>(); // UTA: default value
		DropdownValues item2 = mock(DropdownValues.class);
		dropDownValues2.add(item2);
		underTest.setDropDownValues(dropDownValues2);

		// Then - assertions for this instance of Dropdowns
		assertEquals("dropDownName", underTest.getDropDownName());
		assertNotNull(underTest.getDropDownValues());
		assertEquals(1, underTest.getDropDownValues().size());

	}
}