/**
 * 
 */
package com.simplilearn.unittesting;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import junitparams.Parameters;
import junitparams.converters.Nullable;
import junitparams.mappers.CsvWithHeaderMapper;
import junitparams.FileParameters;
import junitparams.JUnitParamsRunner;
import org.junit.runner.RunWith;

/**
 * Parasoft Jtest UTA: Test class for MessageViewModel
 *
 * @see com.simplilearn.unittesting.MessageViewModel
 * @author IND-Bhavya
 */
@RunWith(JUnitParamsRunner.class)
public class MessageViewModelParameterizedTest {

	/**
	 * Parasoft Jtest UTA: Test for setDeleted(boolean)
	 *
	 * @see com.simplilearn.unittesting.MessageViewModel#setDeleted(boolean)
	 * @author IND-Bhavya
	 */
	@Test
	@FileParameters(value = "classpath:com/simplilearn/unittesting/MessageViewModelParameterizedTest_testSetDeleted_parameters.csv", mapper = CsvWithHeaderMapper.class, encoding = "UTF-8")
	public void testSetDeleted(boolean isDeleted) throws Throwable {
		MessageViewModel underTest = new MessageViewModel();

		underTest.setDeleted(isDeleted);

	}

	/**
	 * Parasoft Jtest UTA: Test for setEncryptedNflowsId(String)
	 *
	 * @see com.simplilearn.unittesting.MessageViewModel#setEncryptedNflowsId(String)
	 * @author IND-Bhavya
	 */
	@Test
	@FileParameters(value = "classpath:com/simplilearn/unittesting/MessageViewModelParameterizedTest_testSetEncryptedNflowsId_parameters.csv", mapper = CsvWithHeaderMapper.class, encoding = "UTF-8")
	public void testSetEncryptedNflowsId(@Nullable(nullIdentifier = "<NULL>") String encryptedNflowsId)
			throws Throwable {
		MessageViewModel underTest = new MessageViewModel();

		underTest.setEncryptedNflowsId(encryptedNflowsId);

	}

	/**
	 * Parasoft Jtest UTA: Test for setFldMessageIsInternal(boolean)
	 *
	 * @see com.simplilearn.unittesting.MessageViewModel#setFldMessageIsInternal(boolean)
	 * @author IND-Bhavya
	 */
	@Test
	@FileParameters(value = "classpath:com/simplilearn/unittesting/MessageViewModelParameterizedTest_testSetFldMessageIsInternal_parameters.csv", mapper = CsvWithHeaderMapper.class, encoding = "UTF-8")
	public void testSetFldMessageIsInternal(boolean fldMessageIsInternal) throws Throwable {
		MessageViewModel underTest = new MessageViewModel();

		underTest.setFldMessageIsInternal(fldMessageIsInternal);

	}

	/**
	 * Parasoft Jtest UTA: Test for setFldMessageReason(String)
	 *
	 * @see com.simplilearn.unittesting.MessageViewModel#setFldMessageReason(String)
	 * @author IND-Bhavya
	 */
	@Test
	@FileParameters(value = "classpath:com/simplilearn/unittesting/MessageViewModelParameterizedTest_testSetFldMessageReason_parameters.csv", mapper = CsvWithHeaderMapper.class, encoding = "UTF-8")
	public void testSetFldMessageReason(@Nullable(nullIdentifier = "<NULL>") String fldMessageReason) throws Throwable {
		MessageViewModel underTest = new MessageViewModel();

		underTest.setFldMessageReason(fldMessageReason);

	}

	/**
	 * Parasoft Jtest UTA: Test for setFldMessageResolution(String)
	 *
	 * @see com.simplilearn.unittesting.MessageViewModel#setFldMessageResolution(String)
	 * @author IND-Bhavya
	 */
	@Test
	@FileParameters(value = "classpath:com/simplilearn/unittesting/MessageViewModelParameterizedTest_testSetFldMessageResolution_parameters.csv", mapper = CsvWithHeaderMapper.class, encoding = "UTF-8")
	public void testSetFldMessageResolution(@Nullable(nullIdentifier = "<NULL>") String fldMessageResolution)
			throws Throwable {
		MessageViewModel underTest = new MessageViewModel();

		underTest.setFldMessageResolution(fldMessageResolution);

	}

	/**
	 * Parasoft Jtest UTA: Test for setFldMessageStatus(boolean)
	 *
	 * @see com.simplilearn.unittesting.MessageViewModel#setFldMessageStatus(boolean)
	 * @author IND-Bhavya
	 */
	@Test
	@FileParameters(value = "classpath:com/simplilearn/unittesting/MessageViewModelParameterizedTest_testSetFldMessageStatus_parameters.csv", mapper = CsvWithHeaderMapper.class, encoding = "UTF-8")
	public void testSetFldMessageStatus(boolean fldMessageStatus) throws Throwable {
		MessageViewModel underTest = new MessageViewModel();

		underTest.setFldMessageStatus(fldMessageStatus);

	}

	/**
	 * Parasoft Jtest UTA: Test for setFldMessageTextType(String)
	 *
	 * @see com.simplilearn.unittesting.MessageViewModel#setFldMessageTextType(String)
	 * @author IND-Bhavya
	 */
	@Test
	@FileParameters(value = "classpath:com/simplilearn/unittesting/MessageViewModelParameterizedTest_testSetFldMessageTextType_parameters.csv", mapper = CsvWithHeaderMapper.class, encoding = "UTF-8")
	public void testSetFldMessageTextType(@Nullable(nullIdentifier = "<NULL>") String fldMessageTextType)
			throws Throwable {
		MessageViewModel underTest = new MessageViewModel();

		underTest.setFldMessageTextType(fldMessageTextType);

	}

	/**
	 * Parasoft Jtest UTA: Test for setFldMessageType(String)
	 *
	 * @see com.simplilearn.unittesting.MessageViewModel#setFldMessageType(String)
	 * @author IND-Bhavya
	 */
	@Test
	@FileParameters(value = "classpath:com/simplilearn/unittesting/MessageViewModelParameterizedTest_testSetFldMessageType_parameters.csv", mapper = CsvWithHeaderMapper.class, encoding = "UTF-8")
	public void testSetFldMessageType(@Nullable(nullIdentifier = "<NULL>") String fldMessageType) throws Throwable {
		MessageViewModel underTest = new MessageViewModel();

		underTest.setFldMessageType(fldMessageType);

	}

	/**
	 * Parasoft Jtest UTA: Test for setFldMessageValue(String)
	 *
	 * @see com.simplilearn.unittesting.MessageViewModel#setFldMessageValue(String)
	 * @author IND-Bhavya
	 */
	@Test
	@FileParameters(value = "classpath:com/simplilearn/unittesting/MessageViewModelParameterizedTest_testSetFldMessageValue_parameters.csv", mapper = CsvWithHeaderMapper.class, encoding = "UTF-8")
	public void testSetFldMessageValue(@Nullable(nullIdentifier = "<NULL>") String fldMessageValue) throws Throwable {
		MessageViewModel underTest = new MessageViewModel();

		underTest.setFldMessageValue(fldMessageValue);

	}

	/**
	 * Parasoft Jtest UTA: Test for setNeo4jId(Long)
	 *
	 * @see com.simplilearn.unittesting.MessageViewModel#setNeo4jId(Long)
	 * @author IND-Bhavya
	 */
	@Test
	@FileParameters(value = "classpath:com/simplilearn/unittesting/MessageViewModelParameterizedTest_testSetNeo4jId_parameters.csv", mapper = CsvWithHeaderMapper.class, encoding = "UTF-8")
	public void testSetNeo4jId(Long neo4jId) throws Throwable {
		MessageViewModel underTest = new MessageViewModel();

		underTest.setNeo4jId(neo4jId);

	}

	/**
	 * Parasoft Jtest UTA: Test for setNflowsId(long)
	 *
	 * @see com.simplilearn.unittesting.MessageViewModel#setNflowsId(long)
	 * @author IND-Bhavya
	 */
	@Test
	@FileParameters(value = "classpath:com/simplilearn/unittesting/MessageViewModelParameterizedTest_testSetNflowsId_parameters.csv", mapper = CsvWithHeaderMapper.class, encoding = "UTF-8")
	public void testSetNflowsId(long nflowsId) throws Throwable {
		MessageViewModel underTest = new MessageViewModel();

		underTest.setNflowsId(nflowsId);

	}
}