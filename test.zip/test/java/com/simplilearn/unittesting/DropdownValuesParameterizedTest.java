/**
 * 
 */
package com.simplilearn.unittesting;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import junitparams.Parameters;
import junitparams.converters.Nullable;
import junitparams.mappers.CsvWithHeaderMapper;
import junitparams.FileParameters;
import junitparams.JUnitParamsRunner;
import org.junit.runner.RunWith;

/**
 * Parasoft Jtest UTA: Test class for DropdownValues
 *
 * @see com.simplilearn.unittesting.DropdownValues
 * @author IND-Bhavya
 */
@RunWith(JUnitParamsRunner.class)
public class DropdownValuesParameterizedTest {

	/**
	 * Parasoft Jtest UTA: Test for setDropDownValue(String)
	 *
	 * @see com.simplilearn.unittesting.DropdownValues#setDropDownValue(String)
	 * @author IND-Bhavya
	 */
	@Test
	@FileParameters(value = "classpath:com/simplilearn/unittesting/DropdownValuesParameterizedTest_testSetDropDownValue_parameters.csv", mapper = CsvWithHeaderMapper.class, encoding = "UTF-8")
	public void testSetDropDownValue(@Nullable(nullIdentifier = "<NULL>") String dropDownValue) throws Throwable {
		DropdownValues underTest = new DropdownValues();

		underTest.setDropDownValue(dropDownValue);

	}
}