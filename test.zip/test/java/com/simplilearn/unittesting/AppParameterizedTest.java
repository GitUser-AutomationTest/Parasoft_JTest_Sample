/**
 * 
 */
package com.simplilearn.unittesting;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;

import java.util.List;

import org.junit.Test;
import junitparams.Parameters;
import junitparams.converters.Nullable;
import junitparams.mappers.CsvWithHeaderMapper;
import junitparams.FileParameters;
import junitparams.JUnitParamsRunner;
import org.junit.runner.RunWith;

/**
 * Parasoft Jtest UTA: Test class for App
 *
 * @see com.simplilearn.unittesting.App
 * @author IND-Bhavya
 */
@RunWith(JUnitParamsRunner.class)
public class AppParameterizedTest {

	/**
	 * Parasoft Jtest UTA: Test for getProperEntityFields(EntityDictionaryFieldDefinitions)
	 *
	 * @see com.simplilearn.unittesting.App#getProperEntityFields(EntityDictionaryFieldDefinitions)
	 * @author IND-Bhavya
	 */
	@Test
	// Parasoft Jtest UTA: No automatically parameterizable values are available. Complete the test with parameters and provide the values in the CSV file.
	@FileParameters(value = "classpath:com/simplilearn/unittesting/AppParameterizedTest_testGetProperEntityFields_parameters.csv", mapper = CsvWithHeaderMapper.class, encoding = "UTF-8")
	public void testGetProperEntityFields(@Nullable(nullIdentifier = "<NULL>") String dataLabel, String fieldName,
			String fieldCode, String dataType, String helpDescription, boolean isPredefined, boolean digitSegregation,
			boolean isSysField, boolean isUsed, boolean isValidUpto, boolean isMultiSelect, boolean isEnforceableField,
			int length, int precision) throws Throwable {
		App underTest = new App();

		String dropDownName = "dropDownName";
		List<DropdownValues> dropDownValues = mock(List.class);
		Dropdowns dropdowns = new Dropdowns(dropDownName, dropDownValues);
		EntityDictionaryFieldDefinitions dictionaryField = new EntityDictionaryFieldDefinitions(dataLabel, fieldName, fieldCode, dataType, helpDescription,
				isPredefined, digitSegregation, isSysField, isUsed, isValidUpto, isMultiSelect, isEnforceableField, length, precision,dropdowns);
		EntityDictionaryFieldDefinitions result = underTest.getProperEntityFields(dictionaryField);

		assertNotNull(result);
	}
}