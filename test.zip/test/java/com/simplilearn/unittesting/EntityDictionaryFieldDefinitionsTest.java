/**
 * 
 */
package com.simplilearn.unittesting;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.mock;

import org.junit.Test;

/**
 * Parasoft Jtest UTA: Test class for EntityDictionaryFieldDefinitions
 *
 * @see com.simplilearn.unittesting.EntityDictionaryFieldDefinitions
 * @author IND-Bhavya
 */
public class EntityDictionaryFieldDefinitionsTest {

	/**
	 * Parasoft Jtest UTA: Test for getDataLabel()
	 *
	 * @see com.simplilearn.unittesting.EntityDictionaryFieldDefinitions#getDataLabel()
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testGetDataLabel() throws Throwable {
		// Given
		String dataLabel = "dataLabel"; // UTA: default value
		String fieldName = "fieldName"; // UTA: default value
		String fieldCode = "fieldCode"; // UTA: default value
		String dataType = "dataType"; // UTA: default value
		String helpDescription = "helpDescription"; // UTA: default value
		boolean isPredefined = false; // UTA: default value
		boolean digitSegregation = false; // UTA: default value
		boolean isSysField = false; // UTA: default value
		boolean isUsed = false; // UTA: default value
		boolean isValidUpto = false; // UTA: default value
		boolean isMultiSelect = false; // UTA: default value
		boolean isEnforceableField = false; // UTA: default value
		int length = 0; // UTA: default value
		int precision = 0; // UTA: default value
		Dropdowns dropdowns = mock(Dropdowns.class);
		EntityDictionaryFieldDefinitions underTest = new EntityDictionaryFieldDefinitions(dataLabel, fieldName,
				fieldCode, dataType, helpDescription, isPredefined, digitSegregation, isSysField, isUsed, isValidUpto,
				isMultiSelect, isEnforceableField, length, precision, dropdowns);

		// When
		String result = underTest.getDataLabel();

		// Then - assertions for result of method getDataLabel()
		assertEquals("dataLabel", result);

		// Then - assertions for this instance of EntityDictionaryFieldDefinitions
		assertEquals("fieldName", underTest.getFieldName());
		assertEquals("fieldCode", underTest.getFieldCode());
		assertEquals("dataType", underTest.getDataType());
		assertEquals("helpDescription", underTest.getHelpDescription());
		assertFalse(underTest.isPredefined());
		assertFalse(underTest.isDigitSegregation());
		assertFalse(underTest.isSysField());
		assertFalse(underTest.isUsed());
		assertFalse(underTest.isValidUpto());
		assertFalse(underTest.isMultiSelect());
		assertFalse(underTest.isEnforceableField());
		assertEquals(0, underTest.getLength());
		assertEquals(0, underTest.getPrecision());
		assertNotNull(underTest.getDropdowns());
		assertNull(underTest.getDropdowns().getDropDownName());
		assertNull(underTest.getDropdowns().getDropDownValues());

	}

	/**
	 * Parasoft Jtest UTA: Test for getDataType()
	 *
	 * @see com.simplilearn.unittesting.EntityDictionaryFieldDefinitions#getDataType()
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testGetDataType() throws Throwable {
		// Given
		String dataLabel = "dataLabel"; // UTA: default value
		String fieldName = "fieldName"; // UTA: default value
		String fieldCode = "fieldCode"; // UTA: default value
		String dataType = "dataType"; // UTA: default value
		String helpDescription = "helpDescription"; // UTA: default value
		boolean isPredefined = false; // UTA: default value
		boolean digitSegregation = false; // UTA: default value
		boolean isSysField = false; // UTA: default value
		boolean isUsed = false; // UTA: default value
		boolean isValidUpto = false; // UTA: default value
		boolean isMultiSelect = false; // UTA: default value
		boolean isEnforceableField = false; // UTA: default value
		int length = 0; // UTA: default value
		int precision = 0; // UTA: default value
		Dropdowns dropdowns = mock(Dropdowns.class);
		EntityDictionaryFieldDefinitions underTest = new EntityDictionaryFieldDefinitions(dataLabel, fieldName,
				fieldCode, dataType, helpDescription, isPredefined, digitSegregation, isSysField, isUsed, isValidUpto,
				isMultiSelect, isEnforceableField, length, precision, dropdowns);

		// When
		String result = underTest.getDataType();

		// Then - assertions for result of method getDataType()
		assertEquals("dataType", result);

		// Then - assertions for this instance of EntityDictionaryFieldDefinitions
		assertEquals("dataLabel", underTest.getDataLabel());
		assertEquals("fieldName", underTest.getFieldName());
		assertEquals("fieldCode", underTest.getFieldCode());
		assertEquals("helpDescription", underTest.getHelpDescription());
		assertFalse(underTest.isPredefined());
		assertFalse(underTest.isDigitSegregation());
		assertFalse(underTest.isSysField());
		assertFalse(underTest.isUsed());
		assertFalse(underTest.isValidUpto());
		assertFalse(underTest.isMultiSelect());
		assertFalse(underTest.isEnforceableField());
		assertEquals(0, underTest.getLength());
		assertEquals(0, underTest.getPrecision());
		assertNotNull(underTest.getDropdowns());
		assertNull(underTest.getDropdowns().getDropDownName());
		assertNull(underTest.getDropdowns().getDropDownValues());

	}

	/**
	 * Parasoft Jtest UTA: Test for getDropdowns()
	 *
	 * @see com.simplilearn.unittesting.EntityDictionaryFieldDefinitions#getDropdowns()
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testGetDropdowns() throws Throwable {
		// Given
		String dataLabel = "dataLabel"; // UTA: default value
		String fieldName = "fieldName"; // UTA: default value
		String fieldCode = "fieldCode"; // UTA: default value
		String dataType = "dataType"; // UTA: default value
		String helpDescription = "helpDescription"; // UTA: default value
		boolean isPredefined = false; // UTA: default value
		boolean digitSegregation = false; // UTA: default value
		boolean isSysField = false; // UTA: default value
		boolean isUsed = false; // UTA: default value
		boolean isValidUpto = false; // UTA: default value
		boolean isMultiSelect = false; // UTA: default value
		boolean isEnforceableField = false; // UTA: default value
		int length = 0; // UTA: default value
		int precision = 0; // UTA: default value
		Dropdowns dropdowns = mock(Dropdowns.class);
		EntityDictionaryFieldDefinitions underTest = new EntityDictionaryFieldDefinitions(dataLabel, fieldName,
				fieldCode, dataType, helpDescription, isPredefined, digitSegregation, isSysField, isUsed, isValidUpto,
				isMultiSelect, isEnforceableField, length, precision, dropdowns);

		// When
		Dropdowns result = underTest.getDropdowns();

		// Then - assertions for result of method getDropdowns()
		assertNotNull(result);
		assertNull(result.getDropDownName());
		assertNull(result.getDropDownValues());

		// Then - assertions for this instance of EntityDictionaryFieldDefinitions
		assertEquals("dataLabel", underTest.getDataLabel());
		assertEquals("fieldName", underTest.getFieldName());
		assertEquals("fieldCode", underTest.getFieldCode());
		assertEquals("dataType", underTest.getDataType());
		assertEquals("helpDescription", underTest.getHelpDescription());
		assertFalse(underTest.isPredefined());
		assertFalse(underTest.isDigitSegregation());
		assertFalse(underTest.isSysField());
		assertFalse(underTest.isUsed());
		assertFalse(underTest.isValidUpto());
		assertFalse(underTest.isMultiSelect());
		assertFalse(underTest.isEnforceableField());
		assertEquals(0, underTest.getLength());
		assertEquals(0, underTest.getPrecision());

	}

	/**
	 * Parasoft Jtest UTA: Test for getFieldCode()
	 *
	 * @see com.simplilearn.unittesting.EntityDictionaryFieldDefinitions#getFieldCode()
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testGetFieldCode() throws Throwable {
		// Given
		String dataLabel = "dataLabel"; // UTA: default value
		String fieldName = "fieldName"; // UTA: default value
		String fieldCode = "fieldCode"; // UTA: default value
		String dataType = "dataType"; // UTA: default value
		String helpDescription = "helpDescription"; // UTA: default value
		boolean isPredefined = false; // UTA: default value
		boolean digitSegregation = false; // UTA: default value
		boolean isSysField = false; // UTA: default value
		boolean isUsed = false; // UTA: default value
		boolean isValidUpto = false; // UTA: default value
		boolean isMultiSelect = false; // UTA: default value
		boolean isEnforceableField = false; // UTA: default value
		int length = 0; // UTA: default value
		int precision = 0; // UTA: default value
		Dropdowns dropdowns = mock(Dropdowns.class);
		EntityDictionaryFieldDefinitions underTest = new EntityDictionaryFieldDefinitions(dataLabel, fieldName,
				fieldCode, dataType, helpDescription, isPredefined, digitSegregation, isSysField, isUsed, isValidUpto,
				isMultiSelect, isEnforceableField, length, precision, dropdowns);

		// When
		String result = underTest.getFieldCode();

		// Then - assertions for result of method getFieldCode()
		assertEquals("fieldCode", result);

		// Then - assertions for this instance of EntityDictionaryFieldDefinitions
		assertEquals("dataLabel", underTest.getDataLabel());
		assertEquals("fieldName", underTest.getFieldName());
		assertEquals("dataType", underTest.getDataType());
		assertEquals("helpDescription", underTest.getHelpDescription());
		assertFalse(underTest.isPredefined());
		assertFalse(underTest.isDigitSegregation());
		assertFalse(underTest.isSysField());
		assertFalse(underTest.isUsed());
		assertFalse(underTest.isValidUpto());
		assertFalse(underTest.isMultiSelect());
		assertFalse(underTest.isEnforceableField());
		assertEquals(0, underTest.getLength());
		assertEquals(0, underTest.getPrecision());
		assertNotNull(underTest.getDropdowns());
		assertNull(underTest.getDropdowns().getDropDownName());
		assertNull(underTest.getDropdowns().getDropDownValues());

	}

	/**
	 * Parasoft Jtest UTA: Test for getFieldName()
	 *
	 * @see com.simplilearn.unittesting.EntityDictionaryFieldDefinitions#getFieldName()
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testGetFieldName() throws Throwable {
		// Given
		String dataLabel = "dataLabel"; // UTA: default value
		String fieldName = "fieldName"; // UTA: default value
		String fieldCode = "fieldCode"; // UTA: default value
		String dataType = "dataType"; // UTA: default value
		String helpDescription = "helpDescription"; // UTA: default value
		boolean isPredefined = false; // UTA: default value
		boolean digitSegregation = false; // UTA: default value
		boolean isSysField = false; // UTA: default value
		boolean isUsed = false; // UTA: default value
		boolean isValidUpto = false; // UTA: default value
		boolean isMultiSelect = false; // UTA: default value
		boolean isEnforceableField = false; // UTA: default value
		int length = 0; // UTA: default value
		int precision = 0; // UTA: default value
		Dropdowns dropdowns = mock(Dropdowns.class);
		EntityDictionaryFieldDefinitions underTest = new EntityDictionaryFieldDefinitions(dataLabel, fieldName,
				fieldCode, dataType, helpDescription, isPredefined, digitSegregation, isSysField, isUsed, isValidUpto,
				isMultiSelect, isEnforceableField, length, precision, dropdowns);

		// When
		String result = underTest.getFieldName();

		// Then - assertions for result of method getFieldName()
		assertEquals("fieldName", result);

		// Then - assertions for this instance of EntityDictionaryFieldDefinitions
		assertEquals("dataLabel", underTest.getDataLabel());
		assertEquals("fieldCode", underTest.getFieldCode());
		assertEquals("dataType", underTest.getDataType());
		assertEquals("helpDescription", underTest.getHelpDescription());
		assertFalse(underTest.isPredefined());
		assertFalse(underTest.isDigitSegregation());
		assertFalse(underTest.isSysField());
		assertFalse(underTest.isUsed());
		assertFalse(underTest.isValidUpto());
		assertFalse(underTest.isMultiSelect());
		assertFalse(underTest.isEnforceableField());
		assertEquals(0, underTest.getLength());
		assertEquals(0, underTest.getPrecision());
		assertNotNull(underTest.getDropdowns());
		assertNull(underTest.getDropdowns().getDropDownName());
		assertNull(underTest.getDropdowns().getDropDownValues());

	}

	/**
	 * Parasoft Jtest UTA: Test for getHelpDescription()
	 *
	 * @see com.simplilearn.unittesting.EntityDictionaryFieldDefinitions#getHelpDescription()
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testGetHelpDescription() throws Throwable {
		// Given
		String dataLabel = "dataLabel"; // UTA: default value
		String fieldName = "fieldName"; // UTA: default value
		String fieldCode = "fieldCode"; // UTA: default value
		String dataType = "dataType"; // UTA: default value
		String helpDescription = "helpDescription"; // UTA: default value
		boolean isPredefined = false; // UTA: default value
		boolean digitSegregation = false; // UTA: default value
		boolean isSysField = false; // UTA: default value
		boolean isUsed = false; // UTA: default value
		boolean isValidUpto = false; // UTA: default value
		boolean isMultiSelect = false; // UTA: default value
		boolean isEnforceableField = false; // UTA: default value
		int length = 0; // UTA: default value
		int precision = 0; // UTA: default value
		Dropdowns dropdowns = mock(Dropdowns.class);
		EntityDictionaryFieldDefinitions underTest = new EntityDictionaryFieldDefinitions(dataLabel, fieldName,
				fieldCode, dataType, helpDescription, isPredefined, digitSegregation, isSysField, isUsed, isValidUpto,
				isMultiSelect, isEnforceableField, length, precision, dropdowns);

		// When
		String result = underTest.getHelpDescription();

		// Then - assertions for result of method getHelpDescription()
		assertEquals("helpDescription", result);

		// Then - assertions for this instance of EntityDictionaryFieldDefinitions
		assertEquals("dataLabel", underTest.getDataLabel());
		assertEquals("fieldName", underTest.getFieldName());
		assertEquals("fieldCode", underTest.getFieldCode());
		assertEquals("dataType", underTest.getDataType());
		assertFalse(underTest.isPredefined());
		assertFalse(underTest.isDigitSegregation());
		assertFalse(underTest.isSysField());
		assertFalse(underTest.isUsed());
		assertFalse(underTest.isValidUpto());
		assertFalse(underTest.isMultiSelect());
		assertFalse(underTest.isEnforceableField());
		assertEquals(0, underTest.getLength());
		assertEquals(0, underTest.getPrecision());
		assertNotNull(underTest.getDropdowns());
		assertNull(underTest.getDropdowns().getDropDownName());
		assertNull(underTest.getDropdowns().getDropDownValues());

	}

	/**
	 * Parasoft Jtest UTA: Test for getLength()
	 *
	 * @see com.simplilearn.unittesting.EntityDictionaryFieldDefinitions#getLength()
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testGetLength() throws Throwable {
		// Given
		String dataLabel = "dataLabel"; // UTA: default value
		String fieldName = "fieldName"; // UTA: default value
		String fieldCode = "fieldCode"; // UTA: default value
		String dataType = "dataType"; // UTA: default value
		String helpDescription = "helpDescription"; // UTA: default value
		boolean isPredefined = false; // UTA: default value
		boolean digitSegregation = false; // UTA: default value
		boolean isSysField = false; // UTA: default value
		boolean isUsed = false; // UTA: default value
		boolean isValidUpto = false; // UTA: default value
		boolean isMultiSelect = false; // UTA: default value
		boolean isEnforceableField = false; // UTA: default value
		int length = 0; // UTA: default value
		int precision = 0; // UTA: default value
		Dropdowns dropdowns = mock(Dropdowns.class);
		EntityDictionaryFieldDefinitions underTest = new EntityDictionaryFieldDefinitions(dataLabel, fieldName,
				fieldCode, dataType, helpDescription, isPredefined, digitSegregation, isSysField, isUsed, isValidUpto,
				isMultiSelect, isEnforceableField, length, precision, dropdowns);

		// When
		int result = underTest.getLength();

		// Then - assertions for result of method getLength()
		assertEquals(0, result);

		// Then - assertions for this instance of EntityDictionaryFieldDefinitions
		assertEquals("dataLabel", underTest.getDataLabel());
		assertEquals("fieldName", underTest.getFieldName());
		assertEquals("fieldCode", underTest.getFieldCode());
		assertEquals("dataType", underTest.getDataType());
		assertEquals("helpDescription", underTest.getHelpDescription());
		assertFalse(underTest.isPredefined());
		assertFalse(underTest.isDigitSegregation());
		assertFalse(underTest.isSysField());
		assertFalse(underTest.isUsed());
		assertFalse(underTest.isValidUpto());
		assertFalse(underTest.isMultiSelect());
		assertFalse(underTest.isEnforceableField());
		assertEquals(0, underTest.getPrecision());
		assertNotNull(underTest.getDropdowns());
		assertNull(underTest.getDropdowns().getDropDownName());
		assertNull(underTest.getDropdowns().getDropDownValues());

	}

	/**
	 * Parasoft Jtest UTA: Test for getPrecision()
	 *
	 * @see com.simplilearn.unittesting.EntityDictionaryFieldDefinitions#getPrecision()
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testGetPrecision() throws Throwable {
		// Given
		String dataLabel = "dataLabel"; // UTA: default value
		String fieldName = "fieldName"; // UTA: default value
		String fieldCode = "fieldCode"; // UTA: default value
		String dataType = "dataType"; // UTA: default value
		String helpDescription = "helpDescription"; // UTA: default value
		boolean isPredefined = false; // UTA: default value
		boolean digitSegregation = false; // UTA: default value
		boolean isSysField = false; // UTA: default value
		boolean isUsed = false; // UTA: default value
		boolean isValidUpto = false; // UTA: default value
		boolean isMultiSelect = false; // UTA: default value
		boolean isEnforceableField = false; // UTA: default value
		int length = 0; // UTA: default value
		int precision = 0; // UTA: default value
		Dropdowns dropdowns = mock(Dropdowns.class);
		EntityDictionaryFieldDefinitions underTest = new EntityDictionaryFieldDefinitions(dataLabel, fieldName,
				fieldCode, dataType, helpDescription, isPredefined, digitSegregation, isSysField, isUsed, isValidUpto,
				isMultiSelect, isEnforceableField, length, precision, dropdowns);

		// When
		int result = underTest.getPrecision();

		// Then - assertions for result of method getPrecision()
		assertEquals(0, result);

		// Then - assertions for this instance of EntityDictionaryFieldDefinitions
		assertEquals("dataLabel", underTest.getDataLabel());
		assertEquals("fieldName", underTest.getFieldName());
		assertEquals("fieldCode", underTest.getFieldCode());
		assertEquals("dataType", underTest.getDataType());
		assertEquals("helpDescription", underTest.getHelpDescription());
		assertFalse(underTest.isPredefined());
		assertFalse(underTest.isDigitSegregation());
		assertFalse(underTest.isSysField());
		assertFalse(underTest.isUsed());
		assertFalse(underTest.isValidUpto());
		assertFalse(underTest.isMultiSelect());
		assertFalse(underTest.isEnforceableField());
		assertEquals(0, underTest.getLength());
		assertNotNull(underTest.getDropdowns());
		assertNull(underTest.getDropdowns().getDropDownName());
		assertNull(underTest.getDropdowns().getDropDownValues());

	}

	/**
	 * Parasoft Jtest UTA: Test for isDigitSegregation()
	 *
	 * @see com.simplilearn.unittesting.EntityDictionaryFieldDefinitions#isDigitSegregation()
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testIsDigitSegregation() throws Throwable {
		// Given
		String dataLabel = "dataLabel"; // UTA: default value
		String fieldName = "fieldName"; // UTA: default value
		String fieldCode = "fieldCode"; // UTA: default value
		String dataType = "dataType"; // UTA: default value
		String helpDescription = "helpDescription"; // UTA: default value
		boolean isPredefined = false; // UTA: default value
		boolean digitSegregation = false; // UTA: default value
		boolean isSysField = false; // UTA: default value
		boolean isUsed = false; // UTA: default value
		boolean isValidUpto = false; // UTA: default value
		boolean isMultiSelect = false; // UTA: default value
		boolean isEnforceableField = false; // UTA: default value
		int length = 0; // UTA: default value
		int precision = 0; // UTA: default value
		Dropdowns dropdowns = mock(Dropdowns.class);
		EntityDictionaryFieldDefinitions underTest = new EntityDictionaryFieldDefinitions(dataLabel, fieldName,
				fieldCode, dataType, helpDescription, isPredefined, digitSegregation, isSysField, isUsed, isValidUpto,
				isMultiSelect, isEnforceableField, length, precision, dropdowns);

		// When
		boolean result = underTest.isDigitSegregation();

		// Then - assertions for result of method isDigitSegregation()
		assertFalse(result);

		// Then - assertions for this instance of EntityDictionaryFieldDefinitions
		assertEquals("dataLabel", underTest.getDataLabel());
		assertEquals("fieldName", underTest.getFieldName());
		assertEquals("fieldCode", underTest.getFieldCode());
		assertEquals("dataType", underTest.getDataType());
		assertEquals("helpDescription", underTest.getHelpDescription());
		assertFalse(underTest.isPredefined());
		assertFalse(underTest.isSysField());
		assertFalse(underTest.isUsed());
		assertFalse(underTest.isValidUpto());
		assertFalse(underTest.isMultiSelect());
		assertFalse(underTest.isEnforceableField());
		assertEquals(0, underTest.getLength());
		assertEquals(0, underTest.getPrecision());
		assertNotNull(underTest.getDropdowns());
		assertNull(underTest.getDropdowns().getDropDownName());
		assertNull(underTest.getDropdowns().getDropDownValues());

	}

	/**
	 * Parasoft Jtest UTA: Test for isEnforceableField()
	 *
	 * @see com.simplilearn.unittesting.EntityDictionaryFieldDefinitions#isEnforceableField()
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testIsEnforceableField() throws Throwable {
		// Given
		String dataLabel = "dataLabel"; // UTA: default value
		String fieldName = "fieldName"; // UTA: default value
		String fieldCode = "fieldCode"; // UTA: default value
		String dataType = "dataType"; // UTA: default value
		String helpDescription = "helpDescription"; // UTA: default value
		boolean isPredefined = false; // UTA: default value
		boolean digitSegregation = false; // UTA: default value
		boolean isSysField = false; // UTA: default value
		boolean isUsed = false; // UTA: default value
		boolean isValidUpto = false; // UTA: default value
		boolean isMultiSelect = false; // UTA: default value
		boolean isEnforceableField = false; // UTA: default value
		int length = 0; // UTA: default value
		int precision = 0; // UTA: default value
		Dropdowns dropdowns = mock(Dropdowns.class);
		EntityDictionaryFieldDefinitions underTest = new EntityDictionaryFieldDefinitions(dataLabel, fieldName,
				fieldCode, dataType, helpDescription, isPredefined, digitSegregation, isSysField, isUsed, isValidUpto,
				isMultiSelect, isEnforceableField, length, precision, dropdowns);

		// When
		boolean result = underTest.isEnforceableField();

		// Then - assertions for result of method isEnforceableField()
		assertFalse(result);

		// Then - assertions for this instance of EntityDictionaryFieldDefinitions
		assertEquals("dataLabel", underTest.getDataLabel());
		assertEquals("fieldName", underTest.getFieldName());
		assertEquals("fieldCode", underTest.getFieldCode());
		assertEquals("dataType", underTest.getDataType());
		assertEquals("helpDescription", underTest.getHelpDescription());
		assertFalse(underTest.isPredefined());
		assertFalse(underTest.isDigitSegregation());
		assertFalse(underTest.isSysField());
		assertFalse(underTest.isUsed());
		assertFalse(underTest.isValidUpto());
		assertFalse(underTest.isMultiSelect());
		assertEquals(0, underTest.getLength());
		assertEquals(0, underTest.getPrecision());
		assertNotNull(underTest.getDropdowns());
		assertNull(underTest.getDropdowns().getDropDownName());
		assertNull(underTest.getDropdowns().getDropDownValues());

	}

	/**
	 * Parasoft Jtest UTA: Test for isMultiSelect()
	 *
	 * @see com.simplilearn.unittesting.EntityDictionaryFieldDefinitions#isMultiSelect()
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testIsMultiSelect() throws Throwable {
		// Given
		String dataLabel = "dataLabel"; // UTA: default value
		String fieldName = "fieldName"; // UTA: default value
		String fieldCode = "fieldCode"; // UTA: default value
		String dataType = "dataType"; // UTA: default value
		String helpDescription = "helpDescription"; // UTA: default value
		boolean isPredefined = false; // UTA: default value
		boolean digitSegregation = false; // UTA: default value
		boolean isSysField = false; // UTA: default value
		boolean isUsed = false; // UTA: default value
		boolean isValidUpto = false; // UTA: default value
		boolean isMultiSelect = false; // UTA: default value
		boolean isEnforceableField = false; // UTA: default value
		int length = 0; // UTA: default value
		int precision = 0; // UTA: default value
		Dropdowns dropdowns = mock(Dropdowns.class);
		EntityDictionaryFieldDefinitions underTest = new EntityDictionaryFieldDefinitions(dataLabel, fieldName,
				fieldCode, dataType, helpDescription, isPredefined, digitSegregation, isSysField, isUsed, isValidUpto,
				isMultiSelect, isEnforceableField, length, precision, dropdowns);

		// When
		boolean result = underTest.isMultiSelect();

		// Then - assertions for result of method isMultiSelect()
		assertFalse(result);

		// Then - assertions for this instance of EntityDictionaryFieldDefinitions
		assertEquals("dataLabel", underTest.getDataLabel());
		assertEquals("fieldName", underTest.getFieldName());
		assertEquals("fieldCode", underTest.getFieldCode());
		assertEquals("dataType", underTest.getDataType());
		assertEquals("helpDescription", underTest.getHelpDescription());
		assertFalse(underTest.isPredefined());
		assertFalse(underTest.isDigitSegregation());
		assertFalse(underTest.isSysField());
		assertFalse(underTest.isUsed());
		assertFalse(underTest.isValidUpto());
		assertFalse(underTest.isEnforceableField());
		assertEquals(0, underTest.getLength());
		assertEquals(0, underTest.getPrecision());
		assertNotNull(underTest.getDropdowns());
		assertNull(underTest.getDropdowns().getDropDownName());
		assertNull(underTest.getDropdowns().getDropDownValues());

	}

	/**
	 * Parasoft Jtest UTA: Test for isPredefined()
	 *
	 * @see com.simplilearn.unittesting.EntityDictionaryFieldDefinitions#isPredefined()
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testIsPredefined() throws Throwable {
		// Given
		String dataLabel = "dataLabel"; // UTA: default value
		String fieldName = "fieldName"; // UTA: default value
		String fieldCode = "fieldCode"; // UTA: default value
		String dataType = "dataType"; // UTA: default value
		String helpDescription = "helpDescription"; // UTA: default value
		boolean isPredefined = false; // UTA: default value
		boolean digitSegregation = false; // UTA: default value
		boolean isSysField = false; // UTA: default value
		boolean isUsed = false; // UTA: default value
		boolean isValidUpto = false; // UTA: default value
		boolean isMultiSelect = false; // UTA: default value
		boolean isEnforceableField = false; // UTA: default value
		int length = 0; // UTA: default value
		int precision = 0; // UTA: default value
		Dropdowns dropdowns = mock(Dropdowns.class);
		EntityDictionaryFieldDefinitions underTest = new EntityDictionaryFieldDefinitions(dataLabel, fieldName,
				fieldCode, dataType, helpDescription, isPredefined, digitSegregation, isSysField, isUsed, isValidUpto,
				isMultiSelect, isEnforceableField, length, precision, dropdowns);

		// When
		boolean result = underTest.isPredefined();

		// Then - assertions for result of method isPredefined()
		assertFalse(result);

		// Then - assertions for this instance of EntityDictionaryFieldDefinitions
		assertEquals("dataLabel", underTest.getDataLabel());
		assertEquals("fieldName", underTest.getFieldName());
		assertEquals("fieldCode", underTest.getFieldCode());
		assertEquals("dataType", underTest.getDataType());
		assertEquals("helpDescription", underTest.getHelpDescription());
		assertFalse(underTest.isDigitSegregation());
		assertFalse(underTest.isSysField());
		assertFalse(underTest.isUsed());
		assertFalse(underTest.isValidUpto());
		assertFalse(underTest.isMultiSelect());
		assertFalse(underTest.isEnforceableField());
		assertEquals(0, underTest.getLength());
		assertEquals(0, underTest.getPrecision());
		assertNotNull(underTest.getDropdowns());
		assertNull(underTest.getDropdowns().getDropDownName());
		assertNull(underTest.getDropdowns().getDropDownValues());

	}

	/**
	 * Parasoft Jtest UTA: Test for isSysField()
	 *
	 * @see com.simplilearn.unittesting.EntityDictionaryFieldDefinitions#isSysField()
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testIsSysField() throws Throwable {
		// Given
		String dataLabel = "dataLabel"; // UTA: default value
		String fieldName = "fieldName"; // UTA: default value
		String fieldCode = "fieldCode"; // UTA: default value
		String dataType = "dataType"; // UTA: default value
		String helpDescription = "helpDescription"; // UTA: default value
		boolean isPredefined = false; // UTA: default value
		boolean digitSegregation = false; // UTA: default value
		boolean isSysField = false; // UTA: default value
		boolean isUsed = false; // UTA: default value
		boolean isValidUpto = false; // UTA: default value
		boolean isMultiSelect = false; // UTA: default value
		boolean isEnforceableField = false; // UTA: default value
		int length = 0; // UTA: default value
		int precision = 0; // UTA: default value
		Dropdowns dropdowns = mock(Dropdowns.class);
		EntityDictionaryFieldDefinitions underTest = new EntityDictionaryFieldDefinitions(dataLabel, fieldName,
				fieldCode, dataType, helpDescription, isPredefined, digitSegregation, isSysField, isUsed, isValidUpto,
				isMultiSelect, isEnforceableField, length, precision, dropdowns);

		// When
		boolean result = underTest.isSysField();

		// Then - assertions for result of method isSysField()
		assertFalse(result);

		// Then - assertions for this instance of EntityDictionaryFieldDefinitions
		assertEquals("dataLabel", underTest.getDataLabel());
		assertEquals("fieldName", underTest.getFieldName());
		assertEquals("fieldCode", underTest.getFieldCode());
		assertEquals("dataType", underTest.getDataType());
		assertEquals("helpDescription", underTest.getHelpDescription());
		assertFalse(underTest.isPredefined());
		assertFalse(underTest.isDigitSegregation());
		assertFalse(underTest.isUsed());
		assertFalse(underTest.isValidUpto());
		assertFalse(underTest.isMultiSelect());
		assertFalse(underTest.isEnforceableField());
		assertEquals(0, underTest.getLength());
		assertEquals(0, underTest.getPrecision());
		assertNotNull(underTest.getDropdowns());
		assertNull(underTest.getDropdowns().getDropDownName());
		assertNull(underTest.getDropdowns().getDropDownValues());

	}

	/**
	 * Parasoft Jtest UTA: Test for isUsed()
	 *
	 * @see com.simplilearn.unittesting.EntityDictionaryFieldDefinitions#isUsed()
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testIsUsed() throws Throwable {
		// Given
		String dataLabel = "dataLabel"; // UTA: default value
		String fieldName = "fieldName"; // UTA: default value
		String fieldCode = "fieldCode"; // UTA: default value
		String dataType = "dataType"; // UTA: default value
		String helpDescription = "helpDescription"; // UTA: default value
		boolean isPredefined = false; // UTA: default value
		boolean digitSegregation = false; // UTA: default value
		boolean isSysField = false; // UTA: default value
		boolean isUsed = false; // UTA: default value
		boolean isValidUpto = false; // UTA: default value
		boolean isMultiSelect = false; // UTA: default value
		boolean isEnforceableField = false; // UTA: default value
		int length = 0; // UTA: default value
		int precision = 0; // UTA: default value
		Dropdowns dropdowns = mock(Dropdowns.class);
		EntityDictionaryFieldDefinitions underTest = new EntityDictionaryFieldDefinitions(dataLabel, fieldName,
				fieldCode, dataType, helpDescription, isPredefined, digitSegregation, isSysField, isUsed, isValidUpto,
				isMultiSelect, isEnforceableField, length, precision, dropdowns);

		// When
		boolean result = underTest.isUsed();

		// Then - assertions for result of method isUsed()
		assertFalse(result);

		// Then - assertions for this instance of EntityDictionaryFieldDefinitions
		assertEquals("dataLabel", underTest.getDataLabel());
		assertEquals("fieldName", underTest.getFieldName());
		assertEquals("fieldCode", underTest.getFieldCode());
		assertEquals("dataType", underTest.getDataType());
		assertEquals("helpDescription", underTest.getHelpDescription());
		assertFalse(underTest.isPredefined());
		assertFalse(underTest.isDigitSegregation());
		assertFalse(underTest.isSysField());
		assertFalse(underTest.isValidUpto());
		assertFalse(underTest.isMultiSelect());
		assertFalse(underTest.isEnforceableField());
		assertEquals(0, underTest.getLength());
		assertEquals(0, underTest.getPrecision());
		assertNotNull(underTest.getDropdowns());
		assertNull(underTest.getDropdowns().getDropDownName());
		assertNull(underTest.getDropdowns().getDropDownValues());

	}

	/**
	 * Parasoft Jtest UTA: Test for isValidUpto()
	 *
	 * @see com.simplilearn.unittesting.EntityDictionaryFieldDefinitions#isValidUpto()
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testIsValidUpto() throws Throwable {
		// Given
		String dataLabel = "dataLabel"; // UTA: default value
		String fieldName = "fieldName"; // UTA: default value
		String fieldCode = "fieldCode"; // UTA: default value
		String dataType = "dataType"; // UTA: default value
		String helpDescription = "helpDescription"; // UTA: default value
		boolean isPredefined = false; // UTA: default value
		boolean digitSegregation = false; // UTA: default value
		boolean isSysField = false; // UTA: default value
		boolean isUsed = false; // UTA: default value
		boolean isValidUpto = false; // UTA: default value
		boolean isMultiSelect = false; // UTA: default value
		boolean isEnforceableField = false; // UTA: default value
		int length = 0; // UTA: default value
		int precision = 0; // UTA: default value
		Dropdowns dropdowns = mock(Dropdowns.class);
		EntityDictionaryFieldDefinitions underTest = new EntityDictionaryFieldDefinitions(dataLabel, fieldName,
				fieldCode, dataType, helpDescription, isPredefined, digitSegregation, isSysField, isUsed, isValidUpto,
				isMultiSelect, isEnforceableField, length, precision, dropdowns);

		// When
		boolean result = underTest.isValidUpto();

		// Then - assertions for result of method isValidUpto()
		assertFalse(result);

		// Then - assertions for this instance of EntityDictionaryFieldDefinitions
		assertEquals("dataLabel", underTest.getDataLabel());
		assertEquals("fieldName", underTest.getFieldName());
		assertEquals("fieldCode", underTest.getFieldCode());
		assertEquals("dataType", underTest.getDataType());
		assertEquals("helpDescription", underTest.getHelpDescription());
		assertFalse(underTest.isPredefined());
		assertFalse(underTest.isDigitSegregation());
		assertFalse(underTest.isSysField());
		assertFalse(underTest.isUsed());
		assertFalse(underTest.isMultiSelect());
		assertFalse(underTest.isEnforceableField());
		assertEquals(0, underTest.getLength());
		assertEquals(0, underTest.getPrecision());
		assertNotNull(underTest.getDropdowns());
		assertNull(underTest.getDropdowns().getDropDownName());
		assertNull(underTest.getDropdowns().getDropDownValues());

	}

	/**
	 * Parasoft Jtest UTA: Test for setDataLabel(String)
	 *
	 * @see com.simplilearn.unittesting.EntityDictionaryFieldDefinitions#setDataLabel(String)
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testSetDataLabel() throws Throwable {
		// Given
		String dataLabel = "dataLabel"; // UTA: default value
		String fieldName = "fieldName"; // UTA: default value
		String fieldCode = "fieldCode"; // UTA: default value
		String dataType = "dataType"; // UTA: default value
		String helpDescription = "helpDescription"; // UTA: default value
		boolean isPredefined = false; // UTA: default value
		boolean digitSegregation = false; // UTA: default value
		boolean isSysField = false; // UTA: default value
		boolean isUsed = false; // UTA: default value
		boolean isValidUpto = false; // UTA: default value
		boolean isMultiSelect = false; // UTA: default value
		boolean isEnforceableField = false; // UTA: default value
		int length = 0; // UTA: default value
		int precision = 0; // UTA: default value
		Dropdowns dropdowns = mock(Dropdowns.class);
		EntityDictionaryFieldDefinitions underTest = new EntityDictionaryFieldDefinitions(dataLabel, fieldName,
				fieldCode, dataType, helpDescription, isPredefined, digitSegregation, isSysField, isUsed, isValidUpto,
				isMultiSelect, isEnforceableField, length, precision, dropdowns);

		// When
		String dataLabel2 = "dataLabel2"; // UTA: default value
		underTest.setDataLabel(dataLabel2);

		// Then - assertions for this instance of EntityDictionaryFieldDefinitions
		assertEquals("dataLabel2", underTest.getDataLabel());
		assertEquals("fieldName", underTest.getFieldName());
		assertEquals("fieldCode", underTest.getFieldCode());
		assertEquals("dataType", underTest.getDataType());
		assertEquals("helpDescription", underTest.getHelpDescription());
		assertFalse(underTest.isPredefined());
		assertFalse(underTest.isDigitSegregation());
		assertFalse(underTest.isSysField());
		assertFalse(underTest.isUsed());
		assertFalse(underTest.isValidUpto());
		assertFalse(underTest.isMultiSelect());
		assertFalse(underTest.isEnforceableField());
		assertEquals(0, underTest.getLength());
		assertEquals(0, underTest.getPrecision());
		assertNotNull(underTest.getDropdowns());
		assertNull(underTest.getDropdowns().getDropDownName());
		assertNull(underTest.getDropdowns().getDropDownValues());

	}

	/**
	 * Parasoft Jtest UTA: Test for setDataType(String)
	 *
	 * @see com.simplilearn.unittesting.EntityDictionaryFieldDefinitions#setDataType(String)
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testSetDataType() throws Throwable {
		// Given
		String dataLabel = "dataLabel"; // UTA: default value
		String fieldName = "fieldName"; // UTA: default value
		String fieldCode = "fieldCode"; // UTA: default value
		String dataType = "dataType"; // UTA: default value
		String helpDescription = "helpDescription"; // UTA: default value
		boolean isPredefined = false; // UTA: default value
		boolean digitSegregation = false; // UTA: default value
		boolean isSysField = false; // UTA: default value
		boolean isUsed = false; // UTA: default value
		boolean isValidUpto = false; // UTA: default value
		boolean isMultiSelect = false; // UTA: default value
		boolean isEnforceableField = false; // UTA: default value
		int length = 0; // UTA: default value
		int precision = 0; // UTA: default value
		Dropdowns dropdowns = mock(Dropdowns.class);
		EntityDictionaryFieldDefinitions underTest = new EntityDictionaryFieldDefinitions(dataLabel, fieldName,
				fieldCode, dataType, helpDescription, isPredefined, digitSegregation, isSysField, isUsed, isValidUpto,
				isMultiSelect, isEnforceableField, length, precision, dropdowns);

		// When
		String dataType2 = "dataType2"; // UTA: default value
		underTest.setDataType(dataType2);

		// Then - assertions for this instance of EntityDictionaryFieldDefinitions
		assertEquals("dataLabel", underTest.getDataLabel());
		assertEquals("fieldName", underTest.getFieldName());
		assertEquals("fieldCode", underTest.getFieldCode());
		assertEquals("dataType2", underTest.getDataType());
		assertEquals("helpDescription", underTest.getHelpDescription());
		assertFalse(underTest.isPredefined());
		assertFalse(underTest.isDigitSegregation());
		assertFalse(underTest.isSysField());
		assertFalse(underTest.isUsed());
		assertFalse(underTest.isValidUpto());
		assertFalse(underTest.isMultiSelect());
		assertFalse(underTest.isEnforceableField());
		assertEquals(0, underTest.getLength());
		assertEquals(0, underTest.getPrecision());
		assertNotNull(underTest.getDropdowns());
		assertNull(underTest.getDropdowns().getDropDownName());
		assertNull(underTest.getDropdowns().getDropDownValues());

	}

	/**
	 * Parasoft Jtest UTA: Test for setDigitSegregation(boolean)
	 *
	 * @see com.simplilearn.unittesting.EntityDictionaryFieldDefinitions#setDigitSegregation(boolean)
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testSetDigitSegregation() throws Throwable {
		// Given
		String dataLabel = "dataLabel"; // UTA: default value
		String fieldName = "fieldName"; // UTA: default value
		String fieldCode = "fieldCode"; // UTA: default value
		String dataType = "dataType"; // UTA: default value
		String helpDescription = "helpDescription"; // UTA: default value
		boolean isPredefined = false; // UTA: default value
		boolean digitSegregation = false; // UTA: default value
		boolean isSysField = false; // UTA: default value
		boolean isUsed = false; // UTA: default value
		boolean isValidUpto = false; // UTA: default value
		boolean isMultiSelect = false; // UTA: default value
		boolean isEnforceableField = false; // UTA: default value
		int length = 0; // UTA: default value
		int precision = 0; // UTA: default value
		Dropdowns dropdowns = mock(Dropdowns.class);
		EntityDictionaryFieldDefinitions underTest = new EntityDictionaryFieldDefinitions(dataLabel, fieldName,
				fieldCode, dataType, helpDescription, isPredefined, digitSegregation, isSysField, isUsed, isValidUpto,
				isMultiSelect, isEnforceableField, length, precision, dropdowns);

		// When
		boolean digitSegregation2 = false; // UTA: default value
		underTest.setDigitSegregation(digitSegregation2);

		// Then - assertions for this instance of EntityDictionaryFieldDefinitions
		assertEquals("dataLabel", underTest.getDataLabel());
		assertEquals("fieldName", underTest.getFieldName());
		assertEquals("fieldCode", underTest.getFieldCode());
		assertEquals("dataType", underTest.getDataType());
		assertEquals("helpDescription", underTest.getHelpDescription());
		assertFalse(underTest.isPredefined());
		assertFalse(underTest.isDigitSegregation());
		assertFalse(underTest.isSysField());
		assertFalse(underTest.isUsed());
		assertFalse(underTest.isValidUpto());
		assertFalse(underTest.isMultiSelect());
		assertFalse(underTest.isEnforceableField());
		assertEquals(0, underTest.getLength());
		assertEquals(0, underTest.getPrecision());
		assertNotNull(underTest.getDropdowns());
		assertNull(underTest.getDropdowns().getDropDownName());
		assertNull(underTest.getDropdowns().getDropDownValues());

	}

	/**
	 * Parasoft Jtest UTA: Test for setDropdowns(Dropdowns)
	 *
	 * @see com.simplilearn.unittesting.EntityDictionaryFieldDefinitions#setDropdowns(Dropdowns)
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testSetDropdowns() throws Throwable {
		// Given
		String dataLabel = "dataLabel"; // UTA: default value
		String fieldName = "fieldName"; // UTA: default value
		String fieldCode = "fieldCode"; // UTA: default value
		String dataType = "dataType"; // UTA: default value
		String helpDescription = "helpDescription"; // UTA: default value
		boolean isPredefined = false; // UTA: default value
		boolean digitSegregation = false; // UTA: default value
		boolean isSysField = false; // UTA: default value
		boolean isUsed = false; // UTA: default value
		boolean isValidUpto = false; // UTA: default value
		boolean isMultiSelect = false; // UTA: default value
		boolean isEnforceableField = false; // UTA: default value
		int length = 0; // UTA: default value
		int precision = 0; // UTA: default value
		Dropdowns dropdowns = mock(Dropdowns.class);
		EntityDictionaryFieldDefinitions underTest = new EntityDictionaryFieldDefinitions(dataLabel, fieldName,
				fieldCode, dataType, helpDescription, isPredefined, digitSegregation, isSysField, isUsed, isValidUpto,
				isMultiSelect, isEnforceableField, length, precision, dropdowns);

		// When
		Dropdowns dropdowns2 = mock(Dropdowns.class);
		underTest.setDropdowns(dropdowns2);

		// Then - assertions for argument 1 of method setDropdowns(Dropdowns)
		assertNull(dropdowns2.getDropDownName());
		assertNull(dropdowns2.getDropDownValues());

		// Then - assertions for this instance of EntityDictionaryFieldDefinitions
		assertEquals("dataLabel", underTest.getDataLabel());
		assertEquals("fieldName", underTest.getFieldName());
		assertEquals("fieldCode", underTest.getFieldCode());
		assertEquals("dataType", underTest.getDataType());
		assertEquals("helpDescription", underTest.getHelpDescription());
		assertFalse(underTest.isPredefined());
		assertFalse(underTest.isDigitSegregation());
		assertFalse(underTest.isSysField());
		assertFalse(underTest.isUsed());
		assertFalse(underTest.isValidUpto());
		assertFalse(underTest.isMultiSelect());
		assertFalse(underTest.isEnforceableField());
		assertEquals(0, underTest.getLength());
		assertEquals(0, underTest.getPrecision());
		assertNotNull(underTest.getDropdowns());
		assertNull(underTest.getDropdowns().getDropDownName());
		assertNull(underTest.getDropdowns().getDropDownValues());

	}

	/**
	 * Parasoft Jtest UTA: Test for setEnforceableField(boolean)
	 *
	 * @see com.simplilearn.unittesting.EntityDictionaryFieldDefinitions#setEnforceableField(boolean)
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testSetEnforceableField() throws Throwable {
		// Given
		String dataLabel = "dataLabel"; // UTA: default value
		String fieldName = "fieldName"; // UTA: default value
		String fieldCode = "fieldCode"; // UTA: default value
		String dataType = "dataType"; // UTA: default value
		String helpDescription = "helpDescription"; // UTA: default value
		boolean isPredefined = false; // UTA: default value
		boolean digitSegregation = false; // UTA: default value
		boolean isSysField = false; // UTA: default value
		boolean isUsed = false; // UTA: default value
		boolean isValidUpto = false; // UTA: default value
		boolean isMultiSelect = false; // UTA: default value
		boolean isEnforceableField = false; // UTA: default value
		int length = 0; // UTA: default value
		int precision = 0; // UTA: default value
		Dropdowns dropdowns = mock(Dropdowns.class);
		EntityDictionaryFieldDefinitions underTest = new EntityDictionaryFieldDefinitions(dataLabel, fieldName,
				fieldCode, dataType, helpDescription, isPredefined, digitSegregation, isSysField, isUsed, isValidUpto,
				isMultiSelect, isEnforceableField, length, precision, dropdowns);

		// When
		boolean isEnforceableField2 = false; // UTA: default value
		underTest.setEnforceableField(isEnforceableField2);

		// Then - assertions for this instance of EntityDictionaryFieldDefinitions
		assertEquals("dataLabel", underTest.getDataLabel());
		assertEquals("fieldName", underTest.getFieldName());
		assertEquals("fieldCode", underTest.getFieldCode());
		assertEquals("dataType", underTest.getDataType());
		assertEquals("helpDescription", underTest.getHelpDescription());
		assertFalse(underTest.isPredefined());
		assertFalse(underTest.isDigitSegregation());
		assertFalse(underTest.isSysField());
		assertFalse(underTest.isUsed());
		assertFalse(underTest.isValidUpto());
		assertFalse(underTest.isMultiSelect());
		assertFalse(underTest.isEnforceableField());
		assertEquals(0, underTest.getLength());
		assertEquals(0, underTest.getPrecision());
		assertNotNull(underTest.getDropdowns());
		assertNull(underTest.getDropdowns().getDropDownName());
		assertNull(underTest.getDropdowns().getDropDownValues());

	}

	/**
	 * Parasoft Jtest UTA: Test for setFieldCode(String)
	 *
	 * @see com.simplilearn.unittesting.EntityDictionaryFieldDefinitions#setFieldCode(String)
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testSetFieldCode() throws Throwable {
		// Given
		String dataLabel = "dataLabel"; // UTA: default value
		String fieldName = "fieldName"; // UTA: default value
		String fieldCode = "fieldCode"; // UTA: default value
		String dataType = "dataType"; // UTA: default value
		String helpDescription = "helpDescription"; // UTA: default value
		boolean isPredefined = false; // UTA: default value
		boolean digitSegregation = false; // UTA: default value
		boolean isSysField = false; // UTA: default value
		boolean isUsed = false; // UTA: default value
		boolean isValidUpto = false; // UTA: default value
		boolean isMultiSelect = false; // UTA: default value
		boolean isEnforceableField = false; // UTA: default value
		int length = 0; // UTA: default value
		int precision = 0; // UTA: default value
		Dropdowns dropdowns = mock(Dropdowns.class);
		EntityDictionaryFieldDefinitions underTest = new EntityDictionaryFieldDefinitions(dataLabel, fieldName,
				fieldCode, dataType, helpDescription, isPredefined, digitSegregation, isSysField, isUsed, isValidUpto,
				isMultiSelect, isEnforceableField, length, precision, dropdowns);

		// When
		String fieldCode2 = "fieldCode2"; // UTA: default value
		underTest.setFieldCode(fieldCode2);

		// Then - assertions for this instance of EntityDictionaryFieldDefinitions
		assertEquals("dataLabel", underTest.getDataLabel());
		assertEquals("fieldName", underTest.getFieldName());
		assertEquals("fieldCode2", underTest.getFieldCode());
		assertEquals("dataType", underTest.getDataType());
		assertEquals("helpDescription", underTest.getHelpDescription());
		assertFalse(underTest.isPredefined());
		assertFalse(underTest.isDigitSegregation());
		assertFalse(underTest.isSysField());
		assertFalse(underTest.isUsed());
		assertFalse(underTest.isValidUpto());
		assertFalse(underTest.isMultiSelect());
		assertFalse(underTest.isEnforceableField());
		assertEquals(0, underTest.getLength());
		assertEquals(0, underTest.getPrecision());
		assertNotNull(underTest.getDropdowns());
		assertNull(underTest.getDropdowns().getDropDownName());
		assertNull(underTest.getDropdowns().getDropDownValues());

	}

	/**
	 * Parasoft Jtest UTA: Test for setFieldName(String)
	 *
	 * @see com.simplilearn.unittesting.EntityDictionaryFieldDefinitions#setFieldName(String)
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testSetFieldName() throws Throwable {
		// Given
		String dataLabel = "dataLabel"; // UTA: default value
		String fieldName = "fieldName"; // UTA: default value
		String fieldCode = "fieldCode"; // UTA: default value
		String dataType = "dataType"; // UTA: default value
		String helpDescription = "helpDescription"; // UTA: default value
		boolean isPredefined = false; // UTA: default value
		boolean digitSegregation = false; // UTA: default value
		boolean isSysField = false; // UTA: default value
		boolean isUsed = false; // UTA: default value
		boolean isValidUpto = false; // UTA: default value
		boolean isMultiSelect = false; // UTA: default value
		boolean isEnforceableField = false; // UTA: default value
		int length = 0; // UTA: default value
		int precision = 0; // UTA: default value
		Dropdowns dropdowns = mock(Dropdowns.class);
		EntityDictionaryFieldDefinitions underTest = new EntityDictionaryFieldDefinitions(dataLabel, fieldName,
				fieldCode, dataType, helpDescription, isPredefined, digitSegregation, isSysField, isUsed, isValidUpto,
				isMultiSelect, isEnforceableField, length, precision, dropdowns);

		// When
		String fieldName2 = "fieldName2"; // UTA: default value
		underTest.setFieldName(fieldName2);

		// Then - assertions for this instance of EntityDictionaryFieldDefinitions
		assertEquals("dataLabel", underTest.getDataLabel());
		assertEquals("fieldName2", underTest.getFieldName());
		assertEquals("fieldCode", underTest.getFieldCode());
		assertEquals("dataType", underTest.getDataType());
		assertEquals("helpDescription", underTest.getHelpDescription());
		assertFalse(underTest.isPredefined());
		assertFalse(underTest.isDigitSegregation());
		assertFalse(underTest.isSysField());
		assertFalse(underTest.isUsed());
		assertFalse(underTest.isValidUpto());
		assertFalse(underTest.isMultiSelect());
		assertFalse(underTest.isEnforceableField());
		assertEquals(0, underTest.getLength());
		assertEquals(0, underTest.getPrecision());
		assertNotNull(underTest.getDropdowns());
		assertNull(underTest.getDropdowns().getDropDownName());
		assertNull(underTest.getDropdowns().getDropDownValues());

	}

	/**
	 * Parasoft Jtest UTA: Test for setHelpDescription(String)
	 *
	 * @see com.simplilearn.unittesting.EntityDictionaryFieldDefinitions#setHelpDescription(String)
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testSetHelpDescription() throws Throwable {
		// Given
		String dataLabel = "dataLabel"; // UTA: default value
		String fieldName = "fieldName"; // UTA: default value
		String fieldCode = "fieldCode"; // UTA: default value
		String dataType = "dataType"; // UTA: default value
		String helpDescription = "helpDescription"; // UTA: default value
		boolean isPredefined = false; // UTA: default value
		boolean digitSegregation = false; // UTA: default value
		boolean isSysField = false; // UTA: default value
		boolean isUsed = false; // UTA: default value
		boolean isValidUpto = false; // UTA: default value
		boolean isMultiSelect = false; // UTA: default value
		boolean isEnforceableField = false; // UTA: default value
		int length = 0; // UTA: default value
		int precision = 0; // UTA: default value
		Dropdowns dropdowns = mock(Dropdowns.class);
		EntityDictionaryFieldDefinitions underTest = new EntityDictionaryFieldDefinitions(dataLabel, fieldName,
				fieldCode, dataType, helpDescription, isPredefined, digitSegregation, isSysField, isUsed, isValidUpto,
				isMultiSelect, isEnforceableField, length, precision, dropdowns);

		// When
		String helpDescription2 = "helpDescription2"; // UTA: default value
		underTest.setHelpDescription(helpDescription2);

		// Then - assertions for this instance of EntityDictionaryFieldDefinitions
		assertEquals("dataLabel", underTest.getDataLabel());
		assertEquals("fieldName", underTest.getFieldName());
		assertEquals("fieldCode", underTest.getFieldCode());
		assertEquals("dataType", underTest.getDataType());
		assertEquals("helpDescription2", underTest.getHelpDescription());
		assertFalse(underTest.isPredefined());
		assertFalse(underTest.isDigitSegregation());
		assertFalse(underTest.isSysField());
		assertFalse(underTest.isUsed());
		assertFalse(underTest.isValidUpto());
		assertFalse(underTest.isMultiSelect());
		assertFalse(underTest.isEnforceableField());
		assertEquals(0, underTest.getLength());
		assertEquals(0, underTest.getPrecision());
		assertNotNull(underTest.getDropdowns());
		assertNull(underTest.getDropdowns().getDropDownName());
		assertNull(underTest.getDropdowns().getDropDownValues());

	}

	/**
	 * Parasoft Jtest UTA: Test for setLength(int)
	 *
	 * @see com.simplilearn.unittesting.EntityDictionaryFieldDefinitions#setLength(int)
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testSetLength() throws Throwable {
		// Given
		String dataLabel = "dataLabel"; // UTA: default value
		String fieldName = "fieldName"; // UTA: default value
		String fieldCode = "fieldCode"; // UTA: default value
		String dataType = "dataType"; // UTA: default value
		String helpDescription = "helpDescription"; // UTA: default value
		boolean isPredefined = false; // UTA: default value
		boolean digitSegregation = false; // UTA: default value
		boolean isSysField = false; // UTA: default value
		boolean isUsed = false; // UTA: default value
		boolean isValidUpto = false; // UTA: default value
		boolean isMultiSelect = false; // UTA: default value
		boolean isEnforceableField = false; // UTA: default value
		int length = 0; // UTA: default value
		int precision = 0; // UTA: default value
		Dropdowns dropdowns = mock(Dropdowns.class);
		EntityDictionaryFieldDefinitions underTest = new EntityDictionaryFieldDefinitions(dataLabel, fieldName,
				fieldCode, dataType, helpDescription, isPredefined, digitSegregation, isSysField, isUsed, isValidUpto,
				isMultiSelect, isEnforceableField, length, precision, dropdowns);

		// When
		int length2 = 0; // UTA: default value
		underTest.setLength(length2);

		// Then - assertions for this instance of EntityDictionaryFieldDefinitions
		assertEquals("dataLabel", underTest.getDataLabel());
		assertEquals("fieldName", underTest.getFieldName());
		assertEquals("fieldCode", underTest.getFieldCode());
		assertEquals("dataType", underTest.getDataType());
		assertEquals("helpDescription", underTest.getHelpDescription());
		assertFalse(underTest.isPredefined());
		assertFalse(underTest.isDigitSegregation());
		assertFalse(underTest.isSysField());
		assertFalse(underTest.isUsed());
		assertFalse(underTest.isValidUpto());
		assertFalse(underTest.isMultiSelect());
		assertFalse(underTest.isEnforceableField());
		assertEquals(0, underTest.getLength());
		assertEquals(0, underTest.getPrecision());
		assertNotNull(underTest.getDropdowns());
		assertNull(underTest.getDropdowns().getDropDownName());
		assertNull(underTest.getDropdowns().getDropDownValues());

	}

	/**
	 * Parasoft Jtest UTA: Test for setMultiSelect(boolean)
	 *
	 * @see com.simplilearn.unittesting.EntityDictionaryFieldDefinitions#setMultiSelect(boolean)
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testSetMultiSelect() throws Throwable {
		// Given
		String dataLabel = "dataLabel"; // UTA: default value
		String fieldName = "fieldName"; // UTA: default value
		String fieldCode = "fieldCode"; // UTA: default value
		String dataType = "dataType"; // UTA: default value
		String helpDescription = "helpDescription"; // UTA: default value
		boolean isPredefined = false; // UTA: default value
		boolean digitSegregation = false; // UTA: default value
		boolean isSysField = false; // UTA: default value
		boolean isUsed = false; // UTA: default value
		boolean isValidUpto = false; // UTA: default value
		boolean isMultiSelect = false; // UTA: default value
		boolean isEnforceableField = false; // UTA: default value
		int length = 0; // UTA: default value
		int precision = 0; // UTA: default value
		Dropdowns dropdowns = mock(Dropdowns.class);
		EntityDictionaryFieldDefinitions underTest = new EntityDictionaryFieldDefinitions(dataLabel, fieldName,
				fieldCode, dataType, helpDescription, isPredefined, digitSegregation, isSysField, isUsed, isValidUpto,
				isMultiSelect, isEnforceableField, length, precision, dropdowns);

		// When
		boolean isMultiSelect2 = false; // UTA: default value
		underTest.setMultiSelect(isMultiSelect2);

		// Then - assertions for this instance of EntityDictionaryFieldDefinitions
		assertEquals("dataLabel", underTest.getDataLabel());
		assertEquals("fieldName", underTest.getFieldName());
		assertEquals("fieldCode", underTest.getFieldCode());
		assertEquals("dataType", underTest.getDataType());
		assertEquals("helpDescription", underTest.getHelpDescription());
		assertFalse(underTest.isPredefined());
		assertFalse(underTest.isDigitSegregation());
		assertFalse(underTest.isSysField());
		assertFalse(underTest.isUsed());
		assertFalse(underTest.isValidUpto());
		assertFalse(underTest.isMultiSelect());
		assertFalse(underTest.isEnforceableField());
		assertEquals(0, underTest.getLength());
		assertEquals(0, underTest.getPrecision());
		assertNotNull(underTest.getDropdowns());
		assertNull(underTest.getDropdowns().getDropDownName());
		assertNull(underTest.getDropdowns().getDropDownValues());

	}

	/**
	 * Parasoft Jtest UTA: Test for setPrecision(int)
	 *
	 * @see com.simplilearn.unittesting.EntityDictionaryFieldDefinitions#setPrecision(int)
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testSetPrecision() throws Throwable {
		// Given
		String dataLabel = "dataLabel"; // UTA: default value
		String fieldName = "fieldName"; // UTA: default value
		String fieldCode = "fieldCode"; // UTA: default value
		String dataType = "dataType"; // UTA: default value
		String helpDescription = "helpDescription"; // UTA: default value
		boolean isPredefined = false; // UTA: default value
		boolean digitSegregation = false; // UTA: default value
		boolean isSysField = false; // UTA: default value
		boolean isUsed = false; // UTA: default value
		boolean isValidUpto = false; // UTA: default value
		boolean isMultiSelect = false; // UTA: default value
		boolean isEnforceableField = false; // UTA: default value
		int length = 0; // UTA: default value
		int precision = 0; // UTA: default value
		Dropdowns dropdowns = mock(Dropdowns.class);
		EntityDictionaryFieldDefinitions underTest = new EntityDictionaryFieldDefinitions(dataLabel, fieldName,
				fieldCode, dataType, helpDescription, isPredefined, digitSegregation, isSysField, isUsed, isValidUpto,
				isMultiSelect, isEnforceableField, length, precision, dropdowns);

		// When
		int precision2 = 0; // UTA: default value
		underTest.setPrecision(precision2);

		// Then - assertions for this instance of EntityDictionaryFieldDefinitions
		assertEquals("dataLabel", underTest.getDataLabel());
		assertEquals("fieldName", underTest.getFieldName());
		assertEquals("fieldCode", underTest.getFieldCode());
		assertEquals("dataType", underTest.getDataType());
		assertEquals("helpDescription", underTest.getHelpDescription());
		assertFalse(underTest.isPredefined());
		assertFalse(underTest.isDigitSegregation());
		assertFalse(underTest.isSysField());
		assertFalse(underTest.isUsed());
		assertFalse(underTest.isValidUpto());
		assertFalse(underTest.isMultiSelect());
		assertFalse(underTest.isEnforceableField());
		assertEquals(0, underTest.getLength());
		assertEquals(0, underTest.getPrecision());
		assertNotNull(underTest.getDropdowns());
		assertNull(underTest.getDropdowns().getDropDownName());
		assertNull(underTest.getDropdowns().getDropDownValues());

	}

	/**
	 * Parasoft Jtest UTA: Test for setPredefined(boolean)
	 *
	 * @see com.simplilearn.unittesting.EntityDictionaryFieldDefinitions#setPredefined(boolean)
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testSetPredefined() throws Throwable {
		// Given
		String dataLabel = "dataLabel"; // UTA: default value
		String fieldName = "fieldName"; // UTA: default value
		String fieldCode = "fieldCode"; // UTA: default value
		String dataType = "dataType"; // UTA: default value
		String helpDescription = "helpDescription"; // UTA: default value
		boolean isPredefined = false; // UTA: default value
		boolean digitSegregation = false; // UTA: default value
		boolean isSysField = false; // UTA: default value
		boolean isUsed = false; // UTA: default value
		boolean isValidUpto = false; // UTA: default value
		boolean isMultiSelect = false; // UTA: default value
		boolean isEnforceableField = false; // UTA: default value
		int length = 0; // UTA: default value
		int precision = 0; // UTA: default value
		Dropdowns dropdowns = mock(Dropdowns.class);
		EntityDictionaryFieldDefinitions underTest = new EntityDictionaryFieldDefinitions(dataLabel, fieldName,
				fieldCode, dataType, helpDescription, isPredefined, digitSegregation, isSysField, isUsed, isValidUpto,
				isMultiSelect, isEnforceableField, length, precision, dropdowns);

		// When
		boolean isPredefined2 = false; // UTA: default value
		underTest.setPredefined(isPredefined2);

		// Then - assertions for this instance of EntityDictionaryFieldDefinitions
		assertEquals("dataLabel", underTest.getDataLabel());
		assertEquals("fieldName", underTest.getFieldName());
		assertEquals("fieldCode", underTest.getFieldCode());
		assertEquals("dataType", underTest.getDataType());
		assertEquals("helpDescription", underTest.getHelpDescription());
		assertFalse(underTest.isPredefined());
		assertFalse(underTest.isDigitSegregation());
		assertFalse(underTest.isSysField());
		assertFalse(underTest.isUsed());
		assertFalse(underTest.isValidUpto());
		assertFalse(underTest.isMultiSelect());
		assertFalse(underTest.isEnforceableField());
		assertEquals(0, underTest.getLength());
		assertEquals(0, underTest.getPrecision());
		assertNotNull(underTest.getDropdowns());
		assertNull(underTest.getDropdowns().getDropDownName());
		assertNull(underTest.getDropdowns().getDropDownValues());

	}

	/**
	 * Parasoft Jtest UTA: Test for setSysField(boolean)
	 *
	 * @see com.simplilearn.unittesting.EntityDictionaryFieldDefinitions#setSysField(boolean)
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testSetSysField() throws Throwable {
		// Given
		String dataLabel = "dataLabel"; // UTA: default value
		String fieldName = "fieldName"; // UTA: default value
		String fieldCode = "fieldCode"; // UTA: default value
		String dataType = "dataType"; // UTA: default value
		String helpDescription = "helpDescription"; // UTA: default value
		boolean isPredefined = false; // UTA: default value
		boolean digitSegregation = false; // UTA: default value
		boolean isSysField = false; // UTA: default value
		boolean isUsed = false; // UTA: default value
		boolean isValidUpto = false; // UTA: default value
		boolean isMultiSelect = false; // UTA: default value
		boolean isEnforceableField = false; // UTA: default value
		int length = 0; // UTA: default value
		int precision = 0; // UTA: default value
		Dropdowns dropdowns = mock(Dropdowns.class);
		EntityDictionaryFieldDefinitions underTest = new EntityDictionaryFieldDefinitions(dataLabel, fieldName,
				fieldCode, dataType, helpDescription, isPredefined, digitSegregation, isSysField, isUsed, isValidUpto,
				isMultiSelect, isEnforceableField, length, precision, dropdowns);

		// When
		boolean isSysField2 = false; // UTA: default value
		underTest.setSysField(isSysField2);

		// Then - assertions for this instance of EntityDictionaryFieldDefinitions
		assertEquals("dataLabel", underTest.getDataLabel());
		assertEquals("fieldName", underTest.getFieldName());
		assertEquals("fieldCode", underTest.getFieldCode());
		assertEquals("dataType", underTest.getDataType());
		assertEquals("helpDescription", underTest.getHelpDescription());
		assertFalse(underTest.isPredefined());
		assertFalse(underTest.isDigitSegregation());
		assertFalse(underTest.isSysField());
		assertFalse(underTest.isUsed());
		assertFalse(underTest.isValidUpto());
		assertFalse(underTest.isMultiSelect());
		assertFalse(underTest.isEnforceableField());
		assertEquals(0, underTest.getLength());
		assertEquals(0, underTest.getPrecision());
		assertNotNull(underTest.getDropdowns());
		assertNull(underTest.getDropdowns().getDropDownName());
		assertNull(underTest.getDropdowns().getDropDownValues());

	}

	/**
	 * Parasoft Jtest UTA: Test for setUsed(boolean)
	 *
	 * @see com.simplilearn.unittesting.EntityDictionaryFieldDefinitions#setUsed(boolean)
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testSetUsed() throws Throwable {
		// Given
		String dataLabel = "dataLabel"; // UTA: default value
		String fieldName = "fieldName"; // UTA: default value
		String fieldCode = "fieldCode"; // UTA: default value
		String dataType = "dataType"; // UTA: default value
		String helpDescription = "helpDescription"; // UTA: default value
		boolean isPredefined = false; // UTA: default value
		boolean digitSegregation = false; // UTA: default value
		boolean isSysField = false; // UTA: default value
		boolean isUsed = false; // UTA: default value
		boolean isValidUpto = false; // UTA: default value
		boolean isMultiSelect = false; // UTA: default value
		boolean isEnforceableField = false; // UTA: default value
		int length = 0; // UTA: default value
		int precision = 0; // UTA: default value
		Dropdowns dropdowns = mock(Dropdowns.class);
		EntityDictionaryFieldDefinitions underTest = new EntityDictionaryFieldDefinitions(dataLabel, fieldName,
				fieldCode, dataType, helpDescription, isPredefined, digitSegregation, isSysField, isUsed, isValidUpto,
				isMultiSelect, isEnforceableField, length, precision, dropdowns);

		// When
		boolean isUsed2 = false; // UTA: default value
		underTest.setUsed(isUsed2);

		// Then - assertions for this instance of EntityDictionaryFieldDefinitions
		assertEquals("dataLabel", underTest.getDataLabel());
		assertEquals("fieldName", underTest.getFieldName());
		assertEquals("fieldCode", underTest.getFieldCode());
		assertEquals("dataType", underTest.getDataType());
		assertEquals("helpDescription", underTest.getHelpDescription());
		assertFalse(underTest.isPredefined());
		assertFalse(underTest.isDigitSegregation());
		assertFalse(underTest.isSysField());
		assertFalse(underTest.isUsed());
		assertFalse(underTest.isValidUpto());
		assertFalse(underTest.isMultiSelect());
		assertFalse(underTest.isEnforceableField());
		assertEquals(0, underTest.getLength());
		assertEquals(0, underTest.getPrecision());
		assertNotNull(underTest.getDropdowns());
		assertNull(underTest.getDropdowns().getDropDownName());
		assertNull(underTest.getDropdowns().getDropDownValues());

	}

	/**
	 * Parasoft Jtest UTA: Test for setValidUpto(boolean)
	 *
	 * @see com.simplilearn.unittesting.EntityDictionaryFieldDefinitions#setValidUpto(boolean)
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testSetValidUpto() throws Throwable {
		// Given
		String dataLabel = "dataLabel"; // UTA: default value
		String fieldName = "fieldName"; // UTA: default value
		String fieldCode = "fieldCode"; // UTA: default value
		String dataType = "dataType"; // UTA: default value
		String helpDescription = "helpDescription"; // UTA: default value
		boolean isPredefined = false; // UTA: default value
		boolean digitSegregation = false; // UTA: default value
		boolean isSysField = false; // UTA: default value
		boolean isUsed = false; // UTA: default value
		boolean isValidUpto = false; // UTA: default value
		boolean isMultiSelect = false; // UTA: default value
		boolean isEnforceableField = false; // UTA: default value
		int length = 0; // UTA: default value
		int precision = 0; // UTA: default value
		Dropdowns dropdowns = mock(Dropdowns.class);
		EntityDictionaryFieldDefinitions underTest = new EntityDictionaryFieldDefinitions(dataLabel, fieldName,
				fieldCode, dataType, helpDescription, isPredefined, digitSegregation, isSysField, isUsed, isValidUpto,
				isMultiSelect, isEnforceableField, length, precision, dropdowns);

		// When
		boolean isValidUpto2 = false; // UTA: default value
		underTest.setValidUpto(isValidUpto2);

		// Then - assertions for this instance of EntityDictionaryFieldDefinitions
		assertEquals("dataLabel", underTest.getDataLabel());
		assertEquals("fieldName", underTest.getFieldName());
		assertEquals("fieldCode", underTest.getFieldCode());
		assertEquals("dataType", underTest.getDataType());
		assertEquals("helpDescription", underTest.getHelpDescription());
		assertFalse(underTest.isPredefined());
		assertFalse(underTest.isDigitSegregation());
		assertFalse(underTest.isSysField());
		assertFalse(underTest.isUsed());
		assertFalse(underTest.isValidUpto());
		assertFalse(underTest.isMultiSelect());
		assertFalse(underTest.isEnforceableField());
		assertEquals(0, underTest.getLength());
		assertEquals(0, underTest.getPrecision());
		assertNotNull(underTest.getDropdowns());
		assertNull(underTest.getDropdowns().getDropDownName());
		assertNull(underTest.getDropdowns().getDropDownValues());

	}
}