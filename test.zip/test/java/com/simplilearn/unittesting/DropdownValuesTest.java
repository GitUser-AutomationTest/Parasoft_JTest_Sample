/**
 * 
 */
package com.simplilearn.unittesting;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.junit.Test;

/**
 * Parasoft Jtest UTA: Test class for DropdownValues
 *
 * @see com.simplilearn.unittesting.DropdownValues
 * @author IND-Bhavya
 */
public class DropdownValuesTest {

	/**
	 * Parasoft Jtest UTA: Test for getDropDownValue()
	 *
	 * @see com.simplilearn.unittesting.DropdownValues#getDropDownValue()
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testGetDropDownValue() throws Throwable {
		// Given
		DropdownValues underTest = new DropdownValues();

		// When
		String result = underTest.getDropDownValue();

		// Then - assertions for result of method getDropDownValue()
		assertNull(result);

	}

	/**
	 * Parasoft Jtest UTA: Test for setDropDownValue(String)
	 *
	 * @see com.simplilearn.unittesting.DropdownValues#setDropDownValue(String)
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testSetDropDownValue() throws Throwable {
		// Given
		DropdownValues underTest = new DropdownValues();

		// When
		String dropDownValue = "dropDownValue"; // UTA: default value
		underTest.setDropDownValue(dropDownValue);

		// Then - assertions for this instance of DropdownValues
		assertEquals("dropDownValue", underTest.getDropDownValue());

	}
}