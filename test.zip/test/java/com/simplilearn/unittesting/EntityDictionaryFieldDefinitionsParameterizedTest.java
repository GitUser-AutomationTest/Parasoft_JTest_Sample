/**
 * 
 */
package com.simplilearn.unittesting;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;
import org.junit.Test;
import junitparams.Parameters;
import junitparams.converters.Nullable;
import junitparams.mappers.CsvWithHeaderMapper;
import junitparams.FileParameters;
import junitparams.JUnitParamsRunner;
import org.junit.runner.RunWith;

/**
 * Parasoft Jtest UTA: Test class for EntityDictionaryFieldDefinitions
 *
 * @see com.simplilearn.unittesting.EntityDictionaryFieldDefinitions
 * @author IND-Bhavya
 */
@RunWith(JUnitParamsRunner.class)
public class EntityDictionaryFieldDefinitionsParameterizedTest {

	/**
	 * Parasoft Jtest UTA: Test for setDataLabel(String)
	 *
	 * @see com.simplilearn.unittesting.EntityDictionaryFieldDefinitions#setDataLabel(String)
	 * @author IND-Bhavya
	 */
	@Test
	@FileParameters(value = "classpath:com/simplilearn/unittesting/EntityDictionaryFieldDefinitionsParameterizedTest_testSetDataLabel_parameters.csv", mapper = CsvWithHeaderMapper.class, encoding = "UTF-8")
	public void testSetDataLabel(@Nullable(nullIdentifier = "<NULL>") String dataLabel,
			@Nullable(nullIdentifier = "<NULL>") String fieldName,
			@Nullable(nullIdentifier = "<NULL>") String fieldCode, @Nullable(nullIdentifier = "<NULL>") String dataType,
			@Nullable(nullIdentifier = "<NULL>") String helpDescription, boolean isPredefined, boolean digitSegregation,
			boolean isSysField, boolean isUsed, boolean isValidUpto, boolean isMultiSelect, boolean isEnforceableField,
			int length, int precision, @Nullable(nullIdentifier = "<NULL>") String dropDownName,
			@Nullable(nullIdentifier = "<NULL>") String dataLabel2) throws Throwable {
		List<DropdownValues> dropDownValues = new ArrayList<DropdownValues>(); // UTA: default value
		DropdownValues item = new DropdownValues();
		dropDownValues.add(item);
		Dropdowns dropdowns = new Dropdowns(dropDownName, dropDownValues);
		EntityDictionaryFieldDefinitions underTest = new EntityDictionaryFieldDefinitions(dataLabel, fieldName,
				fieldCode, dataType, helpDescription, isPredefined, digitSegregation, isSysField, isUsed, isValidUpto,
				isMultiSelect, isEnforceableField, length, precision, dropdowns);

		underTest.setDataLabel(dataLabel2);

	}

	/**
	 * Parasoft Jtest UTA: Test for setDataType(String)
	 *
	 * @see com.simplilearn.unittesting.EntityDictionaryFieldDefinitions#setDataType(String)
	 * @author IND-Bhavya
	 */
	@Test
	@FileParameters(value = "classpath:com/simplilearn/unittesting/EntityDictionaryFieldDefinitionsParameterizedTest_testSetDataType_parameters.csv", mapper = CsvWithHeaderMapper.class, encoding = "UTF-8")
	public void testSetDataType(@Nullable(nullIdentifier = "<NULL>") String dataLabel,
			@Nullable(nullIdentifier = "<NULL>") String fieldName,
			@Nullable(nullIdentifier = "<NULL>") String fieldCode, @Nullable(nullIdentifier = "<NULL>") String dataType,
			@Nullable(nullIdentifier = "<NULL>") String helpDescription, boolean isPredefined, boolean digitSegregation,
			boolean isSysField, boolean isUsed, boolean isValidUpto, boolean isMultiSelect, boolean isEnforceableField,
			int length, int precision, @Nullable(nullIdentifier = "<NULL>") String dropDownName,
			@Nullable(nullIdentifier = "<NULL>") String dataType2) throws Throwable {
		List<DropdownValues> dropDownValues = new ArrayList<DropdownValues>(); // UTA: default value
		DropdownValues item = new DropdownValues();
		dropDownValues.add(item);
		Dropdowns dropdowns = new Dropdowns(dropDownName, dropDownValues);
		EntityDictionaryFieldDefinitions underTest = new EntityDictionaryFieldDefinitions(dataLabel, fieldName,
				fieldCode, dataType, helpDescription, isPredefined, digitSegregation, isSysField, isUsed, isValidUpto,
				isMultiSelect, isEnforceableField, length, precision, dropdowns);

		underTest.setDataType(dataType2);

	}

	/**
	 * Parasoft Jtest UTA: Test for setDigitSegregation(boolean)
	 *
	 * @see com.simplilearn.unittesting.EntityDictionaryFieldDefinitions#setDigitSegregation(boolean)
	 * @author IND-Bhavya
	 */
	@Test
	@FileParameters(value = "classpath:com/simplilearn/unittesting/EntityDictionaryFieldDefinitionsParameterizedTest_testSetDigitSegregation_parameters.csv", mapper = CsvWithHeaderMapper.class, encoding = "UTF-8")
	public void testSetDigitSegregation(@Nullable(nullIdentifier = "<NULL>") String dataLabel,
			@Nullable(nullIdentifier = "<NULL>") String fieldName,
			@Nullable(nullIdentifier = "<NULL>") String fieldCode, @Nullable(nullIdentifier = "<NULL>") String dataType,
			@Nullable(nullIdentifier = "<NULL>") String helpDescription, boolean isPredefined, boolean digitSegregation,
			boolean isSysField, boolean isUsed, boolean isValidUpto, boolean isMultiSelect, boolean isEnforceableField,
			int length, int precision, @Nullable(nullIdentifier = "<NULL>") String dropDownName,
			boolean digitSegregation2) throws Throwable {
		List<DropdownValues> dropDownValues = new ArrayList<DropdownValues>(); // UTA: default value
		DropdownValues item = new DropdownValues();
		dropDownValues.add(item);
		Dropdowns dropdowns = new Dropdowns(dropDownName, dropDownValues);
		EntityDictionaryFieldDefinitions underTest = new EntityDictionaryFieldDefinitions(dataLabel, fieldName,
				fieldCode, dataType, helpDescription, isPredefined, digitSegregation, isSysField, isUsed, isValidUpto,
				isMultiSelect, isEnforceableField, length, precision, dropdowns);

		underTest.setDigitSegregation(digitSegregation2);

	}

	/**
	 * Parasoft Jtest UTA: Test for setDropdowns(Dropdowns)
	 *
	 * @see com.simplilearn.unittesting.EntityDictionaryFieldDefinitions#setDropdowns(Dropdowns)
	 * @author IND-Bhavya
	 */
	@Test
	@FileParameters(value = "classpath:com/simplilearn/unittesting/EntityDictionaryFieldDefinitionsParameterizedTest_testSetDropdowns_parameters.csv", mapper = CsvWithHeaderMapper.class, encoding = "UTF-8")
	public void testSetDropdowns(@Nullable(nullIdentifier = "<NULL>") String dataLabel,
			@Nullable(nullIdentifier = "<NULL>") String fieldName,
			@Nullable(nullIdentifier = "<NULL>") String fieldCode, @Nullable(nullIdentifier = "<NULL>") String dataType,
			@Nullable(nullIdentifier = "<NULL>") String helpDescription, boolean isPredefined, boolean digitSegregation,
			boolean isSysField, boolean isUsed, boolean isValidUpto, boolean isMultiSelect, boolean isEnforceableField,
			int length, int precision, @Nullable(nullIdentifier = "<NULL>") String dropDownName,
			@Nullable(nullIdentifier = "<NULL>") String dropDownName2) throws Throwable {
		List<DropdownValues> dropDownValues = new ArrayList<DropdownValues>(); // UTA: default value
		DropdownValues item = new DropdownValues();
		dropDownValues.add(item);
		Dropdowns dropdowns = new Dropdowns(dropDownName, dropDownValues);
		EntityDictionaryFieldDefinitions underTest = new EntityDictionaryFieldDefinitions(dataLabel, fieldName,
				fieldCode, dataType, helpDescription, isPredefined, digitSegregation, isSysField, isUsed, isValidUpto,
				isMultiSelect, isEnforceableField, length, precision, dropdowns);

		List<DropdownValues> dropDownValues2 = new ArrayList<DropdownValues>(); // UTA: default value
		DropdownValues item2 = new DropdownValues();
		dropDownValues2.add(item2);
		Dropdowns dropdowns2 = new Dropdowns(dropDownName2, dropDownValues2);
		underTest.setDropdowns(dropdowns2);

	}

	/**
	 * Parasoft Jtest UTA: Test for setEnforceableField(boolean)
	 *
	 * @see com.simplilearn.unittesting.EntityDictionaryFieldDefinitions#setEnforceableField(boolean)
	 * @author IND-Bhavya
	 */
	@Test
	@FileParameters(value = "classpath:com/simplilearn/unittesting/EntityDictionaryFieldDefinitionsParameterizedTest_testSetEnforceableField_parameters.csv", mapper = CsvWithHeaderMapper.class, encoding = "UTF-8")
	public void testSetEnforceableField(@Nullable(nullIdentifier = "<NULL>") String dataLabel,
			@Nullable(nullIdentifier = "<NULL>") String fieldName,
			@Nullable(nullIdentifier = "<NULL>") String fieldCode, @Nullable(nullIdentifier = "<NULL>") String dataType,
			@Nullable(nullIdentifier = "<NULL>") String helpDescription, boolean isPredefined, boolean digitSegregation,
			boolean isSysField, boolean isUsed, boolean isValidUpto, boolean isMultiSelect, boolean isEnforceableField,
			int length, int precision, @Nullable(nullIdentifier = "<NULL>") String dropDownName,
			boolean isEnforceableField2) throws Throwable {
		List<DropdownValues> dropDownValues = new ArrayList<DropdownValues>(); // UTA: default value
		DropdownValues item = new DropdownValues();
		dropDownValues.add(item);
		Dropdowns dropdowns = new Dropdowns(dropDownName, dropDownValues);
		EntityDictionaryFieldDefinitions underTest = new EntityDictionaryFieldDefinitions(dataLabel, fieldName,
				fieldCode, dataType, helpDescription, isPredefined, digitSegregation, isSysField, isUsed, isValidUpto,
				isMultiSelect, isEnforceableField, length, precision, dropdowns);

		underTest.setEnforceableField(isEnforceableField2);

	}

	/**
	 * Parasoft Jtest UTA: Test for setFieldCode(String)
	 *
	 * @see com.simplilearn.unittesting.EntityDictionaryFieldDefinitions#setFieldCode(String)
	 * @author IND-Bhavya
	 */
	@Test
	@FileParameters(value = "classpath:com/simplilearn/unittesting/EntityDictionaryFieldDefinitionsParameterizedTest_testSetFieldCode_parameters.csv", mapper = CsvWithHeaderMapper.class, encoding = "UTF-8")
	public void testSetFieldCode(@Nullable(nullIdentifier = "<NULL>") String dataLabel,
			@Nullable(nullIdentifier = "<NULL>") String fieldName,
			@Nullable(nullIdentifier = "<NULL>") String fieldCode, @Nullable(nullIdentifier = "<NULL>") String dataType,
			@Nullable(nullIdentifier = "<NULL>") String helpDescription, boolean isPredefined, boolean digitSegregation,
			boolean isSysField, boolean isUsed, boolean isValidUpto, boolean isMultiSelect, boolean isEnforceableField,
			int length, int precision, @Nullable(nullIdentifier = "<NULL>") String dropDownName,
			@Nullable(nullIdentifier = "<NULL>") String fieldCode2) throws Throwable {
		List<DropdownValues> dropDownValues = new ArrayList<DropdownValues>(); // UTA: default value
		DropdownValues item = new DropdownValues();
		dropDownValues.add(item);
		Dropdowns dropdowns = new Dropdowns(dropDownName, dropDownValues);
		EntityDictionaryFieldDefinitions underTest = new EntityDictionaryFieldDefinitions(dataLabel, fieldName,
				fieldCode, dataType, helpDescription, isPredefined, digitSegregation, isSysField, isUsed, isValidUpto,
				isMultiSelect, isEnforceableField, length, precision, dropdowns);

		underTest.setFieldCode(fieldCode2);

	}

	/**
	 * Parasoft Jtest UTA: Test for setFieldName(String)
	 *
	 * @see com.simplilearn.unittesting.EntityDictionaryFieldDefinitions#setFieldName(String)
	 * @author IND-Bhavya
	 */
	@Test
	@FileParameters(value = "classpath:com/simplilearn/unittesting/EntityDictionaryFieldDefinitionsParameterizedTest_testSetFieldName_parameters.csv", mapper = CsvWithHeaderMapper.class, encoding = "UTF-8")
	public void testSetFieldName(@Nullable(nullIdentifier = "<NULL>") String dataLabel,
			@Nullable(nullIdentifier = "<NULL>") String fieldName,
			@Nullable(nullIdentifier = "<NULL>") String fieldCode, @Nullable(nullIdentifier = "<NULL>") String dataType,
			@Nullable(nullIdentifier = "<NULL>") String helpDescription, boolean isPredefined, boolean digitSegregation,
			boolean isSysField, boolean isUsed, boolean isValidUpto, boolean isMultiSelect, boolean isEnforceableField,
			int length, int precision, @Nullable(nullIdentifier = "<NULL>") String dropDownName,
			@Nullable(nullIdentifier = "<NULL>") String fieldName2) throws Throwable {
		List<DropdownValues> dropDownValues = new ArrayList<DropdownValues>(); // UTA: default value
		DropdownValues item = new DropdownValues();
		dropDownValues.add(item);
		Dropdowns dropdowns = new Dropdowns(dropDownName, dropDownValues);
		EntityDictionaryFieldDefinitions underTest = new EntityDictionaryFieldDefinitions(dataLabel, fieldName,
				fieldCode, dataType, helpDescription, isPredefined, digitSegregation, isSysField, isUsed, isValidUpto,
				isMultiSelect, isEnforceableField, length, precision, dropdowns);

		underTest.setFieldName(fieldName2);

	}

	/**
	 * Parasoft Jtest UTA: Test for setHelpDescription(String)
	 *
	 * @see com.simplilearn.unittesting.EntityDictionaryFieldDefinitions#setHelpDescription(String)
	 * @author IND-Bhavya
	 */
	@Test
	@FileParameters(value = "classpath:com/simplilearn/unittesting/EntityDictionaryFieldDefinitionsParameterizedTest_testSetHelpDescription_parameters.csv", mapper = CsvWithHeaderMapper.class, encoding = "UTF-8")
	public void testSetHelpDescription(@Nullable(nullIdentifier = "<NULL>") String dataLabel,
			@Nullable(nullIdentifier = "<NULL>") String fieldName,
			@Nullable(nullIdentifier = "<NULL>") String fieldCode, @Nullable(nullIdentifier = "<NULL>") String dataType,
			@Nullable(nullIdentifier = "<NULL>") String helpDescription, boolean isPredefined, boolean digitSegregation,
			boolean isSysField, boolean isUsed, boolean isValidUpto, boolean isMultiSelect, boolean isEnforceableField,
			int length, int precision, @Nullable(nullIdentifier = "<NULL>") String dropDownName,
			@Nullable(nullIdentifier = "<NULL>") String helpDescription2) throws Throwable {
		List<DropdownValues> dropDownValues = new ArrayList<DropdownValues>(); // UTA: default value
		DropdownValues item = new DropdownValues();
		dropDownValues.add(item);
		Dropdowns dropdowns = new Dropdowns(dropDownName, dropDownValues);
		EntityDictionaryFieldDefinitions underTest = new EntityDictionaryFieldDefinitions(dataLabel, fieldName,
				fieldCode, dataType, helpDescription, isPredefined, digitSegregation, isSysField, isUsed, isValidUpto,
				isMultiSelect, isEnforceableField, length, precision, dropdowns);

		underTest.setHelpDescription(helpDescription2);

	}

	/**
	 * Parasoft Jtest UTA: Test for setLength(int)
	 *
	 * @see com.simplilearn.unittesting.EntityDictionaryFieldDefinitions#setLength(int)
	 * @author IND-Bhavya
	 */
	@Test
	@FileParameters(value = "classpath:com/simplilearn/unittesting/EntityDictionaryFieldDefinitionsParameterizedTest_testSetLength_parameters.csv", mapper = CsvWithHeaderMapper.class, encoding = "UTF-8")
	public void testSetLength(@Nullable(nullIdentifier = "<NULL>") String dataLabel,
			@Nullable(nullIdentifier = "<NULL>") String fieldName,
			@Nullable(nullIdentifier = "<NULL>") String fieldCode, @Nullable(nullIdentifier = "<NULL>") String dataType,
			@Nullable(nullIdentifier = "<NULL>") String helpDescription, boolean isPredefined, boolean digitSegregation,
			boolean isSysField, boolean isUsed, boolean isValidUpto, boolean isMultiSelect, boolean isEnforceableField,
			int length, int precision, @Nullable(nullIdentifier = "<NULL>") String dropDownName, int length2)
			throws Throwable {
		List<DropdownValues> dropDownValues = new ArrayList<DropdownValues>(); // UTA: default value
		DropdownValues item = new DropdownValues();
		dropDownValues.add(item);
		Dropdowns dropdowns = new Dropdowns(dropDownName, dropDownValues);
		EntityDictionaryFieldDefinitions underTest = new EntityDictionaryFieldDefinitions(dataLabel, fieldName,
				fieldCode, dataType, helpDescription, isPredefined, digitSegregation, isSysField, isUsed, isValidUpto,
				isMultiSelect, isEnforceableField, length, precision, dropdowns);

		underTest.setLength(length2);

	}

	/**
	 * Parasoft Jtest UTA: Test for setMultiSelect(boolean)
	 *
	 * @see com.simplilearn.unittesting.EntityDictionaryFieldDefinitions#setMultiSelect(boolean)
	 * @author IND-Bhavya
	 */
	@Test
	@FileParameters(value = "classpath:com/simplilearn/unittesting/EntityDictionaryFieldDefinitionsParameterizedTest_testSetMultiSelect_parameters.csv", mapper = CsvWithHeaderMapper.class, encoding = "UTF-8")
	public void testSetMultiSelect(@Nullable(nullIdentifier = "<NULL>") String dataLabel,
			@Nullable(nullIdentifier = "<NULL>") String fieldName,
			@Nullable(nullIdentifier = "<NULL>") String fieldCode, @Nullable(nullIdentifier = "<NULL>") String dataType,
			@Nullable(nullIdentifier = "<NULL>") String helpDescription, boolean isPredefined, boolean digitSegregation,
			boolean isSysField, boolean isUsed, boolean isValidUpto, boolean isMultiSelect, boolean isEnforceableField,
			int length, int precision, @Nullable(nullIdentifier = "<NULL>") String dropDownName, boolean isMultiSelect2)
			throws Throwable {
		List<DropdownValues> dropDownValues = new ArrayList<DropdownValues>(); // UTA: default value
		DropdownValues item = new DropdownValues();
		dropDownValues.add(item);
		Dropdowns dropdowns = new Dropdowns(dropDownName, dropDownValues);
		EntityDictionaryFieldDefinitions underTest = new EntityDictionaryFieldDefinitions(dataLabel, fieldName,
				fieldCode, dataType, helpDescription, isPredefined, digitSegregation, isSysField, isUsed, isValidUpto,
				isMultiSelect, isEnforceableField, length, precision, dropdowns);

		underTest.setMultiSelect(isMultiSelect2);

	}

	/**
	 * Parasoft Jtest UTA: Test for setPrecision(int)
	 *
	 * @see com.simplilearn.unittesting.EntityDictionaryFieldDefinitions#setPrecision(int)
	 * @author IND-Bhavya
	 */
	@Test
	@FileParameters(value = "classpath:com/simplilearn/unittesting/EntityDictionaryFieldDefinitionsParameterizedTest_testSetPrecision_parameters.csv", mapper = CsvWithHeaderMapper.class, encoding = "UTF-8")
	public void testSetPrecision(@Nullable(nullIdentifier = "<NULL>") String dataLabel,
			@Nullable(nullIdentifier = "<NULL>") String fieldName,
			@Nullable(nullIdentifier = "<NULL>") String fieldCode, @Nullable(nullIdentifier = "<NULL>") String dataType,
			@Nullable(nullIdentifier = "<NULL>") String helpDescription, boolean isPredefined, boolean digitSegregation,
			boolean isSysField, boolean isUsed, boolean isValidUpto, boolean isMultiSelect, boolean isEnforceableField,
			int length, int precision, @Nullable(nullIdentifier = "<NULL>") String dropDownName, int precision2)
			throws Throwable {
		List<DropdownValues> dropDownValues = new ArrayList<DropdownValues>(); // UTA: default value
		DropdownValues item = new DropdownValues();
		dropDownValues.add(item);
		Dropdowns dropdowns = new Dropdowns(dropDownName, dropDownValues);
		EntityDictionaryFieldDefinitions underTest = new EntityDictionaryFieldDefinitions(dataLabel, fieldName,
				fieldCode, dataType, helpDescription, isPredefined, digitSegregation, isSysField, isUsed, isValidUpto,
				isMultiSelect, isEnforceableField, length, precision, dropdowns);

		underTest.setPrecision(precision2);

	}

	/**
	 * Parasoft Jtest UTA: Test for setPredefined(boolean)
	 *
	 * @see com.simplilearn.unittesting.EntityDictionaryFieldDefinitions#setPredefined(boolean)
	 * @author IND-Bhavya
	 */
	@Test
	@FileParameters(value = "classpath:com/simplilearn/unittesting/EntityDictionaryFieldDefinitionsParameterizedTest_testSetPredefined_parameters.csv", mapper = CsvWithHeaderMapper.class, encoding = "UTF-8")
	public void testSetPredefined(@Nullable(nullIdentifier = "<NULL>") String dataLabel,
			@Nullable(nullIdentifier = "<NULL>") String fieldName,
			@Nullable(nullIdentifier = "<NULL>") String fieldCode, @Nullable(nullIdentifier = "<NULL>") String dataType,
			@Nullable(nullIdentifier = "<NULL>") String helpDescription, boolean isPredefined, boolean digitSegregation,
			boolean isSysField, boolean isUsed, boolean isValidUpto, boolean isMultiSelect, boolean isEnforceableField,
			int length, int precision, @Nullable(nullIdentifier = "<NULL>") String dropDownName, boolean isPredefined2)
			throws Throwable {
		List<DropdownValues> dropDownValues = new ArrayList<DropdownValues>(); // UTA: default value
		DropdownValues item = new DropdownValues();
		dropDownValues.add(item);
		Dropdowns dropdowns = new Dropdowns(dropDownName, dropDownValues);
		EntityDictionaryFieldDefinitions underTest = new EntityDictionaryFieldDefinitions(dataLabel, fieldName,
				fieldCode, dataType, helpDescription, isPredefined, digitSegregation, isSysField, isUsed, isValidUpto,
				isMultiSelect, isEnforceableField, length, precision, dropdowns);

		underTest.setPredefined(isPredefined2);

	}

	/**
	 * Parasoft Jtest UTA: Test for setSysField(boolean)
	 *
	 * @see com.simplilearn.unittesting.EntityDictionaryFieldDefinitions#setSysField(boolean)
	 * @author IND-Bhavya
	 */
	@Test
	@FileParameters(value = "classpath:com/simplilearn/unittesting/EntityDictionaryFieldDefinitionsParameterizedTest_testSetSysField_parameters.csv", mapper = CsvWithHeaderMapper.class, encoding = "UTF-8")
	public void testSetSysField(@Nullable(nullIdentifier = "<NULL>") String dataLabel,
			@Nullable(nullIdentifier = "<NULL>") String fieldName,
			@Nullable(nullIdentifier = "<NULL>") String fieldCode, @Nullable(nullIdentifier = "<NULL>") String dataType,
			@Nullable(nullIdentifier = "<NULL>") String helpDescription, boolean isPredefined, boolean digitSegregation,
			boolean isSysField, boolean isUsed, boolean isValidUpto, boolean isMultiSelect, boolean isEnforceableField,
			int length, int precision, @Nullable(nullIdentifier = "<NULL>") String dropDownName, boolean isSysField2)
			throws Throwable {
		List<DropdownValues> dropDownValues = new ArrayList<DropdownValues>(); // UTA: default value
		DropdownValues item = new DropdownValues();
		dropDownValues.add(item);
		Dropdowns dropdowns = new Dropdowns(dropDownName, dropDownValues);
		EntityDictionaryFieldDefinitions underTest = new EntityDictionaryFieldDefinitions(dataLabel, fieldName,
				fieldCode, dataType, helpDescription, isPredefined, digitSegregation, isSysField, isUsed, isValidUpto,
				isMultiSelect, isEnforceableField, length, precision, dropdowns);

		underTest.setSysField(isSysField2);

	}

	/**
	 * Parasoft Jtest UTA: Test for setUsed(boolean)
	 *
	 * @see com.simplilearn.unittesting.EntityDictionaryFieldDefinitions#setUsed(boolean)
	 * @author IND-Bhavya
	 */
	@Test
	@FileParameters(value = "classpath:com/simplilearn/unittesting/EntityDictionaryFieldDefinitionsParameterizedTest_testSetUsed_parameters.csv", mapper = CsvWithHeaderMapper.class, encoding = "UTF-8")
	public void testSetUsed(@Nullable(nullIdentifier = "<NULL>") String dataLabel,
			@Nullable(nullIdentifier = "<NULL>") String fieldName,
			@Nullable(nullIdentifier = "<NULL>") String fieldCode, @Nullable(nullIdentifier = "<NULL>") String dataType,
			@Nullable(nullIdentifier = "<NULL>") String helpDescription, boolean isPredefined, boolean digitSegregation,
			boolean isSysField, boolean isUsed, boolean isValidUpto, boolean isMultiSelect, boolean isEnforceableField,
			int length, int precision, @Nullable(nullIdentifier = "<NULL>") String dropDownName, boolean isUsed2)
			throws Throwable {
		List<DropdownValues> dropDownValues = new ArrayList<DropdownValues>(); // UTA: default value
		DropdownValues item = new DropdownValues();
		dropDownValues.add(item);
		Dropdowns dropdowns = new Dropdowns(dropDownName, dropDownValues);
		EntityDictionaryFieldDefinitions underTest = new EntityDictionaryFieldDefinitions(dataLabel, fieldName,
				fieldCode, dataType, helpDescription, isPredefined, digitSegregation, isSysField, isUsed, isValidUpto,
				isMultiSelect, isEnforceableField, length, precision, dropdowns);

		underTest.setUsed(isUsed2);

	}

	/**
	 * Parasoft Jtest UTA: Test for setValidUpto(boolean)
	 *
	 * @see com.simplilearn.unittesting.EntityDictionaryFieldDefinitions#setValidUpto(boolean)
	 * @author IND-Bhavya
	 */
	@Test
	@FileParameters(value = "classpath:com/simplilearn/unittesting/EntityDictionaryFieldDefinitionsParameterizedTest_testSetValidUpto_parameters.csv", mapper = CsvWithHeaderMapper.class, encoding = "UTF-8")
	public void testSetValidUpto(@Nullable(nullIdentifier = "<NULL>") String dataLabel,
			@Nullable(nullIdentifier = "<NULL>") String fieldName,
			@Nullable(nullIdentifier = "<NULL>") String fieldCode, @Nullable(nullIdentifier = "<NULL>") String dataType,
			@Nullable(nullIdentifier = "<NULL>") String helpDescription, boolean isPredefined, boolean digitSegregation,
			boolean isSysField, boolean isUsed, boolean isValidUpto, boolean isMultiSelect, boolean isEnforceableField,
			int length, int precision, @Nullable(nullIdentifier = "<NULL>") String dropDownName, boolean isValidUpto2)
			throws Throwable {
		List<DropdownValues> dropDownValues = new ArrayList<DropdownValues>(); // UTA: default value
		DropdownValues item = new DropdownValues();
		dropDownValues.add(item);
		Dropdowns dropdowns = new Dropdowns(dropDownName, dropDownValues);
		EntityDictionaryFieldDefinitions underTest = new EntityDictionaryFieldDefinitions(dataLabel, fieldName,
				fieldCode, dataType, helpDescription, isPredefined, digitSegregation, isSysField, isUsed, isValidUpto,
				isMultiSelect, isEnforceableField, length, precision, dropdowns);

		underTest.setValidUpto(isValidUpto2);

	}
}