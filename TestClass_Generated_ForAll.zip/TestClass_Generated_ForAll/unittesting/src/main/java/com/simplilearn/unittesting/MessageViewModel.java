package com.simplilearn.unittesting;

public class MessageViewModel {
	
	private String fldMessageValue;
	private String fldMessageTextType;
	private String fldMessageType;
	private String fldMessageReason;
	private String fldMessageResolution;
	private boolean fldMessageStatus;
	private boolean fldMessageIsInternal;
	private Long neo4jId;
	private boolean isDeleted;
	private long nflowsId;
	private String encryptedNflowsId;
	
	public String getFldMessageValue() {
		return fldMessageValue;
	}
	public void setFldMessageValue(String fldMessageValue) {
		this.fldMessageValue = fldMessageValue;
	}
	public String getFldMessageTextType() {
		return fldMessageTextType;
	}
	public void setFldMessageTextType(String fldMessageTextType) {
		this.fldMessageTextType = fldMessageTextType;
	}
	public String getFldMessageType() {
		return fldMessageType;
	}
	public void setFldMessageType(String fldMessageType) {
		this.fldMessageType = fldMessageType;
	}
	public String getFldMessageReason() {
		return fldMessageReason;
	}
	public void setFldMessageReason(String fldMessageReason) {
		this.fldMessageReason = fldMessageReason;
	}
	public String getFldMessageResolution() {
		return fldMessageResolution;
	}
	public void setFldMessageResolution(String fldMessageResolution) {
		this.fldMessageResolution = fldMessageResolution;
	}
	public boolean getFldMessageStatus() {
		return fldMessageStatus;
	}
	public void setFldMessageStatus(boolean fldMessageStatus) {
		this.fldMessageStatus = fldMessageStatus;
	}
	public boolean getFldMessageIsInternal() {
		return fldMessageIsInternal;
	}
	public void setFldMessageIsInternal(boolean fldMessageIsInternal) {
		this.fldMessageIsInternal = fldMessageIsInternal;
	}
	public Long getNeo4jId() {
		return neo4jId;
	}
	public void setNeo4jId(Long neo4jId) {
		this.neo4jId = neo4jId;
	}
	public boolean isDeleted() {
		return isDeleted;
	}
	public void setDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}
	public long getNflowsId() {
		return nflowsId;
	}
	public void setNflowsId(long nflowsId) {
		this.nflowsId = nflowsId;
	}
	public String getEncryptedNflowsId() {
		return encryptedNflowsId;
	}
	public void setEncryptedNflowsId(String encryptedNflowsId) {
		this.encryptedNflowsId = encryptedNflowsId;
	}
	
}
