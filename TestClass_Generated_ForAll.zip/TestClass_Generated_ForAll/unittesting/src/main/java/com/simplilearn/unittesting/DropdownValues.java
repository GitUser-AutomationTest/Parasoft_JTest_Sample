package com.simplilearn.unittesting;

import java.util.List;

public class DropdownValues {
	
	

	private String dropDownValue;
	private List<DropdownValues> dropDownValues;

	

	public String getDropDownValue() {
		return dropDownValue;
	}

	public void setDropDownValue(String dropDownValue) {
		this.dropDownValue = dropDownValue;
	}

	public void setDropDownValues(List<DropdownValues> dropDownValues) {
		this.dropDownValues = dropDownValues;
	}
	
	

}
