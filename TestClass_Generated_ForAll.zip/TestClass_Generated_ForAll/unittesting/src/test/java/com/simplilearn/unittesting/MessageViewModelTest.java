/**
 * 
 */
package com.simplilearn.unittesting;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Test;

/**
 * Parasoft Jtest UTA: Test class for MessageViewModel
 *
 * @see com.simplilearn.unittesting.MessageViewModel
 * @author IND-Bhavya
 */
public class MessageViewModelTest {

	/**
	 * Parasoft Jtest UTA: Test for getEncryptedNflowsId()
	 *
	 * @see com.simplilearn.unittesting.MessageViewModel#getEncryptedNflowsId()
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testGetEncryptedNflowsId() throws Throwable {
		// Given
		MessageViewModel underTest = new MessageViewModel();

		// When
		String result = underTest.getEncryptedNflowsId();

		// Then - assertions for result of method getEncryptedNflowsId()
		assertNull(result);

		// Then - assertions for this instance of MessageViewModel
		assertNull(underTest.getFldMessageValue());
		assertNull(underTest.getFldMessageTextType());
		assertNull(underTest.getFldMessageType());
		assertNull(underTest.getFldMessageReason());
		assertNull(underTest.getFldMessageResolution());
		assertFalse(underTest.getFldMessageStatus());
		assertFalse(underTest.getFldMessageIsInternal());
		assertNull(underTest.getNeo4jId());
		assertFalse(underTest.isDeleted());
		assertEquals(0L, underTest.getNflowsId());

	}

	/**
	 * Parasoft Jtest UTA: Test for getFldMessageIsInternal()
	 *
	 * @see com.simplilearn.unittesting.MessageViewModel#getFldMessageIsInternal()
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testGetFldMessageIsInternal() throws Throwable {
		// Given
		MessageViewModel underTest = new MessageViewModel();

		// When
		boolean result = underTest.getFldMessageIsInternal();

		// Then - assertions for result of method getFldMessageIsInternal()
		assertFalse(result);

		// Then - assertions for this instance of MessageViewModel
		assertNull(underTest.getFldMessageValue());
		assertNull(underTest.getFldMessageTextType());
		assertNull(underTest.getFldMessageType());
		assertNull(underTest.getFldMessageReason());
		assertNull(underTest.getFldMessageResolution());
		assertFalse(underTest.getFldMessageStatus());
		assertNull(underTest.getNeo4jId());
		assertFalse(underTest.isDeleted());
		assertEquals(0L, underTest.getNflowsId());
		assertNull(underTest.getEncryptedNflowsId());

	}

	/**
	 * Parasoft Jtest UTA: Test for getFldMessageReason()
	 *
	 * @see com.simplilearn.unittesting.MessageViewModel#getFldMessageReason()
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testGetFldMessageReason() throws Throwable {
		// Given
		MessageViewModel underTest = new MessageViewModel();

		// When
		String result = underTest.getFldMessageReason();

		// Then - assertions for result of method getFldMessageReason()
		assertNull(result);

		// Then - assertions for this instance of MessageViewModel
		assertNull(underTest.getFldMessageValue());
		assertNull(underTest.getFldMessageTextType());
		assertNull(underTest.getFldMessageType());
		assertNull(underTest.getFldMessageResolution());
		assertFalse(underTest.getFldMessageStatus());
		assertFalse(underTest.getFldMessageIsInternal());
		assertNull(underTest.getNeo4jId());
		assertFalse(underTest.isDeleted());
		assertEquals(0L, underTest.getNflowsId());
		assertNull(underTest.getEncryptedNflowsId());

	}

	/**
	 * Parasoft Jtest UTA: Test for getFldMessageResolution()
	 *
	 * @see com.simplilearn.unittesting.MessageViewModel#getFldMessageResolution()
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testGetFldMessageResolution() throws Throwable {
		// Given
		MessageViewModel underTest = new MessageViewModel();

		// When
		String result = underTest.getFldMessageResolution();

		// Then - assertions for result of method getFldMessageResolution()
		assertNull(result);

		// Then - assertions for this instance of MessageViewModel
		assertNull(underTest.getFldMessageValue());
		assertNull(underTest.getFldMessageTextType());
		assertNull(underTest.getFldMessageType());
		assertNull(underTest.getFldMessageReason());
		assertFalse(underTest.getFldMessageStatus());
		assertFalse(underTest.getFldMessageIsInternal());
		assertNull(underTest.getNeo4jId());
		assertFalse(underTest.isDeleted());
		assertEquals(0L, underTest.getNflowsId());
		assertNull(underTest.getEncryptedNflowsId());

	}

	/**
	 * Parasoft Jtest UTA: Test for getFldMessageStatus()
	 *
	 * @see com.simplilearn.unittesting.MessageViewModel#getFldMessageStatus()
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testGetFldMessageStatus() throws Throwable {
		// Given
		MessageViewModel underTest = new MessageViewModel();

		// When
		boolean result = underTest.getFldMessageStatus();

		// Then - assertions for result of method getFldMessageStatus()
		assertFalse(result);

		// Then - assertions for this instance of MessageViewModel
		assertNull(underTest.getFldMessageValue());
		assertNull(underTest.getFldMessageTextType());
		assertNull(underTest.getFldMessageType());
		assertNull(underTest.getFldMessageReason());
		assertNull(underTest.getFldMessageResolution());
		assertFalse(underTest.getFldMessageIsInternal());
		assertNull(underTest.getNeo4jId());
		assertFalse(underTest.isDeleted());
		assertEquals(0L, underTest.getNflowsId());
		assertNull(underTest.getEncryptedNflowsId());

	}

	/**
	 * Parasoft Jtest UTA: Test for getFldMessageTextType()
	 *
	 * @see com.simplilearn.unittesting.MessageViewModel#getFldMessageTextType()
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testGetFldMessageTextType() throws Throwable {
		// Given
		MessageViewModel underTest = new MessageViewModel();

		// When
		String result = underTest.getFldMessageTextType();

		// Then - assertions for result of method getFldMessageTextType()
		assertNull(result);

		// Then - assertions for this instance of MessageViewModel
		assertNull(underTest.getFldMessageValue());
		assertNull(underTest.getFldMessageType());
		assertNull(underTest.getFldMessageReason());
		assertNull(underTest.getFldMessageResolution());
		assertFalse(underTest.getFldMessageStatus());
		assertFalse(underTest.getFldMessageIsInternal());
		assertNull(underTest.getNeo4jId());
		assertFalse(underTest.isDeleted());
		assertEquals(0L, underTest.getNflowsId());
		assertNull(underTest.getEncryptedNflowsId());

	}

	/**
	 * Parasoft Jtest UTA: Test for getFldMessageType()
	 *
	 * @see com.simplilearn.unittesting.MessageViewModel#getFldMessageType()
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testGetFldMessageType() throws Throwable {
		// Given
		MessageViewModel underTest = new MessageViewModel();

		// When
		String result = underTest.getFldMessageType();

		// Then - assertions for result of method getFldMessageType()
		assertNull(result);

		// Then - assertions for this instance of MessageViewModel
		assertNull(underTest.getFldMessageValue());
		assertNull(underTest.getFldMessageTextType());
		assertNull(underTest.getFldMessageReason());
		assertNull(underTest.getFldMessageResolution());
		assertFalse(underTest.getFldMessageStatus());
		assertFalse(underTest.getFldMessageIsInternal());
		assertNull(underTest.getNeo4jId());
		assertFalse(underTest.isDeleted());
		assertEquals(0L, underTest.getNflowsId());
		assertNull(underTest.getEncryptedNflowsId());

	}

	/**
	 * Parasoft Jtest UTA: Test for getFldMessageValue()
	 *
	 * @see com.simplilearn.unittesting.MessageViewModel#getFldMessageValue()
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testGetFldMessageValue() throws Throwable {
		// Given
		MessageViewModel underTest = new MessageViewModel();

		// When
		String result = underTest.getFldMessageValue();

		// Then - assertions for result of method getFldMessageValue()
		assertNull(result);

		// Then - assertions for this instance of MessageViewModel
		assertNull(underTest.getFldMessageTextType());
		assertNull(underTest.getFldMessageType());
		assertNull(underTest.getFldMessageReason());
		assertNull(underTest.getFldMessageResolution());
		assertFalse(underTest.getFldMessageStatus());
		assertFalse(underTest.getFldMessageIsInternal());
		assertNull(underTest.getNeo4jId());
		assertFalse(underTest.isDeleted());
		assertEquals(0L, underTest.getNflowsId());
		assertNull(underTest.getEncryptedNflowsId());

	}

	/**
	 * Parasoft Jtest UTA: Test for getNeo4jId()
	 *
	 * @see com.simplilearn.unittesting.MessageViewModel#getNeo4jId()
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testGetNeo4jId() throws Throwable {
		// Given
		MessageViewModel underTest = new MessageViewModel();

		// When
		Long result = underTest.getNeo4jId();

		// Then - assertions for result of method getNeo4jId()
		assertNull(result);

		// Then - assertions for this instance of MessageViewModel
		assertNull(underTest.getFldMessageValue());
		assertNull(underTest.getFldMessageTextType());
		assertNull(underTest.getFldMessageType());
		assertNull(underTest.getFldMessageReason());
		assertNull(underTest.getFldMessageResolution());
		assertFalse(underTest.getFldMessageStatus());
		assertFalse(underTest.getFldMessageIsInternal());
		assertFalse(underTest.isDeleted());
		assertEquals(0L, underTest.getNflowsId());
		assertNull(underTest.getEncryptedNflowsId());

	}

	/**
	 * Parasoft Jtest UTA: Test for getNflowsId()
	 *
	 * @see com.simplilearn.unittesting.MessageViewModel#getNflowsId()
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testGetNflowsId() throws Throwable {
		// Given
		MessageViewModel underTest = new MessageViewModel();

		// When
		long result = underTest.getNflowsId();

		// Then - assertions for result of method getNflowsId()
		assertEquals(0L, result);

		// Then - assertions for this instance of MessageViewModel
		assertNull(underTest.getFldMessageValue());
		assertNull(underTest.getFldMessageTextType());
		assertNull(underTest.getFldMessageType());
		assertNull(underTest.getFldMessageReason());
		assertNull(underTest.getFldMessageResolution());
		assertFalse(underTest.getFldMessageStatus());
		assertFalse(underTest.getFldMessageIsInternal());
		assertNull(underTest.getNeo4jId());
		assertFalse(underTest.isDeleted());
		assertNull(underTest.getEncryptedNflowsId());

	}

	/**
	 * Parasoft Jtest UTA: Test for isDeleted()
	 *
	 * @see com.simplilearn.unittesting.MessageViewModel#isDeleted()
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testIsDeleted() throws Throwable {
		// Given
		MessageViewModel underTest = new MessageViewModel();

		// When
		boolean result = underTest.isDeleted();

		// Then - assertions for result of method isDeleted()
		assertFalse(result);

		// Then - assertions for this instance of MessageViewModel
		assertNull(underTest.getFldMessageValue());
		assertNull(underTest.getFldMessageTextType());
		assertNull(underTest.getFldMessageType());
		assertNull(underTest.getFldMessageReason());
		assertNull(underTest.getFldMessageResolution());
		assertFalse(underTest.getFldMessageStatus());
		assertFalse(underTest.getFldMessageIsInternal());
		assertNull(underTest.getNeo4jId());
		assertEquals(0L, underTest.getNflowsId());
		assertNull(underTest.getEncryptedNflowsId());

	}

	/**
	 * Parasoft Jtest UTA: Test for setDeleted(boolean)
	 *
	 * @see com.simplilearn.unittesting.MessageViewModel#setDeleted(boolean)
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testSetDeleted() throws Throwable {
		// Given
		MessageViewModel underTest = new MessageViewModel();

		// When
		boolean isDeleted = false; // UTA: default value
		underTest.setDeleted(isDeleted);

		// Then - assertions for this instance of MessageViewModel
		assertNull(underTest.getFldMessageValue());
		assertNull(underTest.getFldMessageTextType());
		assertNull(underTest.getFldMessageType());
		assertNull(underTest.getFldMessageReason());
		assertNull(underTest.getFldMessageResolution());
		assertFalse(underTest.getFldMessageStatus());
		assertFalse(underTest.getFldMessageIsInternal());
		assertNull(underTest.getNeo4jId());
		assertFalse(underTest.isDeleted());
		assertEquals(0L, underTest.getNflowsId());
		assertNull(underTest.getEncryptedNflowsId());

	}

	/**
	 * Parasoft Jtest UTA: Test for setEncryptedNflowsId(String)
	 *
	 * @see com.simplilearn.unittesting.MessageViewModel#setEncryptedNflowsId(String)
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testSetEncryptedNflowsId() throws Throwable {
		// Given
		MessageViewModel underTest = new MessageViewModel();

		// When
		String encryptedNflowsId = "encryptedNflowsId"; // UTA: default value
		underTest.setEncryptedNflowsId(encryptedNflowsId);

		// Then - assertions for this instance of MessageViewModel
		assertNull(underTest.getFldMessageValue());
		assertNull(underTest.getFldMessageTextType());
		assertNull(underTest.getFldMessageType());
		assertNull(underTest.getFldMessageReason());
		assertNull(underTest.getFldMessageResolution());
		assertFalse(underTest.getFldMessageStatus());
		assertFalse(underTest.getFldMessageIsInternal());
		assertNull(underTest.getNeo4jId());
		assertFalse(underTest.isDeleted());
		assertEquals(0L, underTest.getNflowsId());
		assertEquals("encryptedNflowsId", underTest.getEncryptedNflowsId());

	}

	/**
	 * Parasoft Jtest UTA: Test for setFldMessageIsInternal(boolean)
	 *
	 * @see com.simplilearn.unittesting.MessageViewModel#setFldMessageIsInternal(boolean)
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testSetFldMessageIsInternal() throws Throwable {
		// Given
		MessageViewModel underTest = new MessageViewModel();

		// When
		boolean fldMessageIsInternal = false; // UTA: default value
		underTest.setFldMessageIsInternal(fldMessageIsInternal);

		// Then - assertions for this instance of MessageViewModel
		assertNull(underTest.getFldMessageValue());
		assertNull(underTest.getFldMessageTextType());
		assertNull(underTest.getFldMessageType());
		assertNull(underTest.getFldMessageReason());
		assertNull(underTest.getFldMessageResolution());
		assertFalse(underTest.getFldMessageStatus());
		assertFalse(underTest.getFldMessageIsInternal());
		assertNull(underTest.getNeo4jId());
		assertFalse(underTest.isDeleted());
		assertEquals(0L, underTest.getNflowsId());
		assertNull(underTest.getEncryptedNflowsId());

	}

	/**
	 * Parasoft Jtest UTA: Test for setFldMessageReason(String)
	 *
	 * @see com.simplilearn.unittesting.MessageViewModel#setFldMessageReason(String)
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testSetFldMessageReason() throws Throwable {
		// Given
		MessageViewModel underTest = new MessageViewModel();

		// When
		String fldMessageReason = "fldMessageReason"; // UTA: default value
		underTest.setFldMessageReason(fldMessageReason);

		// Then - assertions for this instance of MessageViewModel
		assertNull(underTest.getFldMessageValue());
		assertNull(underTest.getFldMessageTextType());
		assertNull(underTest.getFldMessageType());
		assertEquals("fldMessageReason", underTest.getFldMessageReason());
		assertNull(underTest.getFldMessageResolution());
		assertFalse(underTest.getFldMessageStatus());
		assertFalse(underTest.getFldMessageIsInternal());
		assertNull(underTest.getNeo4jId());
		assertFalse(underTest.isDeleted());
		assertEquals(0L, underTest.getNflowsId());
		assertNull(underTest.getEncryptedNflowsId());

	}

	/**
	 * Parasoft Jtest UTA: Test for setFldMessageResolution(String)
	 *
	 * @see com.simplilearn.unittesting.MessageViewModel#setFldMessageResolution(String)
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testSetFldMessageResolution() throws Throwable {
		// Given
		MessageViewModel underTest = new MessageViewModel();

		// When
		String fldMessageResolution = "fldMessageResolution"; // UTA: default value
		underTest.setFldMessageResolution(fldMessageResolution);

		// Then - assertions for this instance of MessageViewModel
		assertNull(underTest.getFldMessageValue());
		assertNull(underTest.getFldMessageTextType());
		assertNull(underTest.getFldMessageType());
		assertNull(underTest.getFldMessageReason());
		assertEquals("fldMessageResolution", underTest.getFldMessageResolution());
		assertFalse(underTest.getFldMessageStatus());
		assertFalse(underTest.getFldMessageIsInternal());
		assertNull(underTest.getNeo4jId());
		assertFalse(underTest.isDeleted());
		assertEquals(0L, underTest.getNflowsId());
		assertNull(underTest.getEncryptedNflowsId());

	}

	/**
	 * Parasoft Jtest UTA: Test for setFldMessageStatus(boolean)
	 *
	 * @see com.simplilearn.unittesting.MessageViewModel#setFldMessageStatus(boolean)
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testSetFldMessageStatus() throws Throwable {
		// Given
		MessageViewModel underTest = new MessageViewModel();

		// When
		boolean fldMessageStatus = false; // UTA: default value
		underTest.setFldMessageStatus(fldMessageStatus);

		// Then - assertions for this instance of MessageViewModel
		assertNull(underTest.getFldMessageValue());
		assertNull(underTest.getFldMessageTextType());
		assertNull(underTest.getFldMessageType());
		assertNull(underTest.getFldMessageReason());
		assertNull(underTest.getFldMessageResolution());
		assertFalse(underTest.getFldMessageStatus());
		assertFalse(underTest.getFldMessageIsInternal());
		assertNull(underTest.getNeo4jId());
		assertFalse(underTest.isDeleted());
		assertEquals(0L, underTest.getNflowsId());
		assertNull(underTest.getEncryptedNflowsId());

	}

	/**
	 * Parasoft Jtest UTA: Test for setFldMessageTextType(String)
	 *
	 * @see com.simplilearn.unittesting.MessageViewModel#setFldMessageTextType(String)
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testSetFldMessageTextType() throws Throwable {
		// Given
		MessageViewModel underTest = new MessageViewModel();

		// When
		String fldMessageTextType = "fldMessageTextType"; // UTA: default value
		underTest.setFldMessageTextType(fldMessageTextType);

		// Then - assertions for this instance of MessageViewModel
		assertNull(underTest.getFldMessageValue());
		assertEquals("fldMessageTextType", underTest.getFldMessageTextType());
		assertNull(underTest.getFldMessageType());
		assertNull(underTest.getFldMessageReason());
		assertNull(underTest.getFldMessageResolution());
		assertFalse(underTest.getFldMessageStatus());
		assertFalse(underTest.getFldMessageIsInternal());
		assertNull(underTest.getNeo4jId());
		assertFalse(underTest.isDeleted());
		assertEquals(0L, underTest.getNflowsId());
		assertNull(underTest.getEncryptedNflowsId());

	}

	/**
	 * Parasoft Jtest UTA: Test for setFldMessageType(String)
	 *
	 * @see com.simplilearn.unittesting.MessageViewModel#setFldMessageType(String)
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testSetFldMessageType() throws Throwable {
		// Given
		MessageViewModel underTest = new MessageViewModel();

		// When
		String fldMessageType = "fldMessageType"; // UTA: default value
		underTest.setFldMessageType(fldMessageType);

		// Then - assertions for this instance of MessageViewModel
		assertNull(underTest.getFldMessageValue());
		assertNull(underTest.getFldMessageTextType());
		assertEquals("fldMessageType", underTest.getFldMessageType());
		assertNull(underTest.getFldMessageReason());
		assertNull(underTest.getFldMessageResolution());
		assertFalse(underTest.getFldMessageStatus());
		assertFalse(underTest.getFldMessageIsInternal());
		assertNull(underTest.getNeo4jId());
		assertFalse(underTest.isDeleted());
		assertEquals(0L, underTest.getNflowsId());
		assertNull(underTest.getEncryptedNflowsId());

	}

	/**
	 * Parasoft Jtest UTA: Test for setFldMessageValue(String)
	 *
	 * @see com.simplilearn.unittesting.MessageViewModel#setFldMessageValue(String)
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testSetFldMessageValue() throws Throwable {
		// Given
		MessageViewModel underTest = new MessageViewModel();

		// When
		String fldMessageValue = "fldMessageValue"; // UTA: default value
		underTest.setFldMessageValue(fldMessageValue);

		// Then - assertions for this instance of MessageViewModel
		assertEquals("fldMessageValue", underTest.getFldMessageValue());
		assertNull(underTest.getFldMessageTextType());
		assertNull(underTest.getFldMessageType());
		assertNull(underTest.getFldMessageReason());
		assertNull(underTest.getFldMessageResolution());
		assertFalse(underTest.getFldMessageStatus());
		assertFalse(underTest.getFldMessageIsInternal());
		assertNull(underTest.getNeo4jId());
		assertFalse(underTest.isDeleted());
		assertEquals(0L, underTest.getNflowsId());
		assertNull(underTest.getEncryptedNflowsId());

	}

	/**
	 * Parasoft Jtest UTA: Test for setNeo4jId(Long)
	 *
	 * @see com.simplilearn.unittesting.MessageViewModel#setNeo4jId(Long)
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testSetNeo4jId() throws Throwable {
		// Given
		MessageViewModel underTest = new MessageViewModel();

		// When
		Long neo4jId = 0L; // UTA: default value
		underTest.setNeo4jId(neo4jId);

		// Then - assertions for this instance of MessageViewModel
		assertNull(underTest.getFldMessageValue());
		assertNull(underTest.getFldMessageTextType());
		assertNull(underTest.getFldMessageType());
		assertNull(underTest.getFldMessageReason());
		assertNull(underTest.getFldMessageResolution());
		assertFalse(underTest.getFldMessageStatus());
		assertFalse(underTest.getFldMessageIsInternal());
		assertNotNull(underTest.getNeo4jId());
		assertEquals(0L, underTest.getNeo4jId().longValue());
		assertFalse(underTest.isDeleted());
		assertEquals(0L, underTest.getNflowsId());
		assertNull(underTest.getEncryptedNflowsId());

	}

	/**
	 * Parasoft Jtest UTA: Test for setNflowsId(long)
	 *
	 * @see com.simplilearn.unittesting.MessageViewModel#setNflowsId(long)
	 * @author IND-Bhavya
	 */
	@Test(timeout = 5000)
	public void testSetNflowsId() throws Throwable {
		// Given
		MessageViewModel underTest = new MessageViewModel();

		// When
		long nflowsId = 0L; // UTA: default value
		underTest.setNflowsId(nflowsId);

		// Then - assertions for this instance of MessageViewModel
		assertNull(underTest.getFldMessageValue());
		assertNull(underTest.getFldMessageTextType());
		assertNull(underTest.getFldMessageType());
		assertNull(underTest.getFldMessageReason());
		assertNull(underTest.getFldMessageResolution());
		assertFalse(underTest.getFldMessageStatus());
		assertFalse(underTest.getFldMessageIsInternal());
		assertNull(underTest.getNeo4jId());
		assertFalse(underTest.isDeleted());
		assertEquals(0L, underTest.getNflowsId());
		assertNull(underTest.getEncryptedNflowsId());

	}
}