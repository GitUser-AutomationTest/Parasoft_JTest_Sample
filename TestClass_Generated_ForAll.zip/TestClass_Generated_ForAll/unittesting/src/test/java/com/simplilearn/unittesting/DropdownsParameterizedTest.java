/**
 * 
 */
package com.simplilearn.unittesting;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.mock;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import org.junit.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;

import junitparams.Parameters;
import junitparams.converters.Nullable;
import junitparams.mappers.CsvWithHeaderMapper;
import junitparams.FileParameters;
import junitparams.JUnitParamsRunner;
import org.junit.runner.RunWith;

/**
 * Parasoft Jtest UTA: Test class for Dropdowns
 *
 * @see com.simplilearn.unittesting.Dropdowns
 * @author IND-Bhavya
 */
@RunWith(JUnitParamsRunner.class)
public class DropdownsParameterizedTest {
	/**
	 * Parasoft Jtest UTA: Test for setDropDownName(String)
	 *
	 * @see com.simplilearn.unittesting.Dropdowns#setDropDownName(String)
	 * @author IND-Bhavya
	 */
	@Test
	@FileParameters(value = "classpath:com/simplilearn/unittesting/DropdownsParameterizedTest_testSetDropDownName_parameters.csv", mapper = CsvWithHeaderMapper.class, encoding = "UTF-8")
	public void testSetDropDownName(@Nullable(nullIdentifier = "<NULL>") String dropDownName) throws Throwable {
		Dropdowns underTest = new Dropdowns(dropDownName, null);

		underTest.setDropDownName(dropDownName);

	}

	
	@Test(timeout = 5000)
	//@FileParameters(value = "classpath:com/simplilearn/unittesting/DropdownsParameterizedTest_testSetDropDownValues_parameters.csv", mapper = CsvWithHeaderMapper.class, encoding = "UTF-8")
	public void testSetDropDownValues() throws Throwable {
		 //Given
				String dropDownName = "dropDownName"; // UTA: default value
				
			    List dropDownValues = new ArrayList<DropdownValues>(); // UTA: default value
			   
				DropdownValues item = new DropdownValues();
				dropDownValues.add(item);
				Dropdowns underTest = new Dropdowns(dropDownName, dropDownValues);
		
				// When
				List<DropdownValues> dropDownValues2 = new ArrayList<DropdownValues>(); // UTA: default value
				DropdownValues item2 = new DropdownValues();
				dropDownValues2.add(item2);
				underTest.setDropDownValues(dropDownValues2);
		        		
				// Then - assertions for this instance of Dropdowns
				assertEquals("dropDownName", underTest.getDropDownName());
				assertNotNull(underTest.getDropDownValues());
				assertEquals(1, underTest.getDropDownValues().size());
		

	}
			   
}