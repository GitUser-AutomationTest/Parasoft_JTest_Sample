package com.simplilearn.unittesting;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.stream.IntStream;

public class App {
    public static void main( String[] args ){
        System.out.println( "Hello World!" );
    }
    
    public EntityDictionaryFieldDefinitions getProperEntityFields(EntityDictionaryFieldDefinitions dictionaryField) {
    	if(dictionaryField != null) {
    		if(dictionaryField.isSysField()) {
    			dictionaryField.setEnforceableField(true);
    			dictionaryField.setHelpDescription("This Field is a System Defined Field");
    			dictionaryField.setUsed(true);
    		}else {
    			dictionaryField.setEnforceableField(false);
    			dictionaryField.setHelpDescription("This Field is a User Defined Field");
    			dictionaryField.setUsed(false);
    		}
    		if(dictionaryField.getLength()<=0) {
    			if(dictionaryField.getDataType().equalsIgnoreCase("NUM")) {
    				dictionaryField.setLength(15);
    				dictionaryField.setLength(3);
    				dictionaryField.setDigitSegregation(true);
    			}else if(dictionaryField.getDataType().equalsIgnoreCase("MT") || dictionaryField.getDataType().equalsIgnoreCase("RTF")){
    				dictionaryField.setLength(10000);
    			}else {
    				dictionaryField.setLength(1000);
    			}
    		}
    	}else {
    		dictionaryField = new EntityDictionaryFieldDefinitions(null, null, null, null, null, false, false, false, false, false, false, false, 0, 0, null);
    	}
    	return dictionaryField;
    }
    
    public List<Map<String,Object>> mandatoryValidations(Map<String,Object> data,List<Map<String,Object>> fieldProperties){
		List<Map<String,Object>> errorFields = new ArrayList<>();
		if(data !=  null && fieldProperties != null && fieldProperties.size() > 0) {
			fieldProperties.stream().forEach(field ->{
				if(data.containsKey(field.get("fieldCode")) && data.get(field.get("fieldCode")) != null && data.get(field.get("fieldCode").toString()).toString().length() == 0) {
					errorFields.add(field);
				}
			});
		}
		return errorFields;
	}
    
    public static String digitSegregation(String data, String digitSegregator,int digitSegregation,String decimalSegregator,int precision) {
		String formattedValue = "";
		if((!data.trim().isEmpty())) {
			DecimalFormat df = new DecimalFormat();
			DecimalFormatSymbols dfs = new DecimalFormatSymbols();
			dfs.setDecimalSeparator(decimalSegregator.charAt(0));
			dfs.setGroupingSeparator(digitSegregator.charAt(0));
			df.setDecimalFormatSymbols(dfs);
			df.setGroupingSize(digitSegregation);
			df.setMaximumFractionDigits(precision);
			Double scientificDouble = Double.parseDouble(data);
			formattedValue = df.format(scientificDouble);
			if (digitSegregation == 2 && formattedValue.contains(decimalSegregator)) {
				String seperate[] = formattedValue.split("\\" + decimalSegregator);
				String splitstring = rupeeFormat(seperate[0], digitSegregator);
				return splitstring + decimalSegregator + seperate[1];
			} else if (digitSegregation == 2 && !formattedValue.contains(decimalSegregator)) {
				String nodecimalsplitstring = rupeeFormat(formattedValue, digitSegregator);
				return nodecimalsplitstring;
			}
		}else
			formattedValue = data;
		return formattedValue;
	}
    
    public static String rupeeFormat(String value, String segregator) {
		value = value.replace(segregator, "");
		char lastDigit = value.charAt(value.length() - 1);
		String result = "";
		int len = value.length() - 1;
		int nDigits = 0;
		for (int i = len - 1; i >= 0; i--) {
			result = value.charAt(i) + result;
			nDigits++;
			if (((nDigits % 2) == 0) && (i > 0)) {
				result = segregator + result;
			}
		}
		return (result + lastDigit);
	}
    
    public List<MessageViewModel> transformDataForValidationMessages(List<Map<String,Object>> messageData) {
		List<MessageViewModel> messages = new ArrayList<>();
		if(messageData.size() > 0)
			messageData.forEach(data -> {
				MessageViewModel msgViewModel = new MessageViewModel();
				msgViewModel.setFldMessageValue(data.getOrDefault("msgValues","").toString());
				msgViewModel.setFldMessageType(data.getOrDefault("msgTextType","").toString());
				if(data.get("msgReasons") != null)
					msgViewModel.setFldMessageReason(data.getOrDefault("msgReasons","").toString());
				else
					msgViewModel.setFldMessageReason("");
				if(data.get("msgResolutions") != null)
					msgViewModel.setFldMessageResolution(data.getOrDefault("msgResolutions","").toString());
				else
					msgViewModel.setFldMessageResolution("");
				msgViewModel.setFldMessageTextType(data.getOrDefault("parameterValueDisplayText","").toString());
				msgViewModel.setNflowsId(Long.parseLong(data.getOrDefault("nflowsId","").toString()));
				msgViewModel.setNeo4jId(Long.parseLong(data.getOrDefault("neo4jId","").toString()));
				messages.add(msgViewModel);
			});
		return messages;
	}
    
    public static String changeDateFormatFromZonedDateFormat(ZonedDateTime inputDate,String outputFormat,boolean isFractions) {
		String date = "", fraction = "", AMPM="";
		if((inputDate != null) && (outputFormat.length() > 0) ) {
			if(inputDate.toString().contains(".") && isFractions) {
				String convertedDate = inputDate.toString();
				int lastIndex = convertedDate.lastIndexOf(".");
				fraction = convertedDate.substring(lastIndex, convertedDate.length()-1);
			}
			
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat(outputFormat);
			simpleDateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
			date = simpleDateFormat.format(Date.from(inputDate.toInstant()));
			
			if(date.charAt(date.length()-1)=='M') {
				int lastIndex = date.lastIndexOf(" ");
				AMPM= date.substring(lastIndex,date.length());
				date =  date.substring(0,lastIndex);
				date = !fraction.isEmpty() ? date+Double.toString(Double.parseDouble(fraction)).substring(1)+AMPM : date+AMPM ;
			}
			else
				date = !fraction.isEmpty() ? date+Double.toString(Double.parseDouble(fraction)).substring(1) : date;
		}
		return date;
	}
    
    public String concatenate(String commonDelimeter, List<Map<String, Object>> fields, Boolean condition) {
		StringBuilder sb = new StringBuilder();
		if (fields != null && (condition == null || condition)) {
			IntStream.range(0, fields.size()).forEach(idx -> {
				if (fields.get(idx) != null && fields.get(idx).getOrDefault("field", "") != null) {
					sb.append(fields.get(idx).getOrDefault("field", ""));
				}
				if (idx < fields.size() - 1) {
					if (fields.get(idx).containsKey("delimeter")) {
						sb.append(fields.get(idx).getOrDefault("delimeter", ""));
					} else {
						sb.append(commonDelimeter);
					}
				}
			});
		}
		return sb.toString();
	}
}
