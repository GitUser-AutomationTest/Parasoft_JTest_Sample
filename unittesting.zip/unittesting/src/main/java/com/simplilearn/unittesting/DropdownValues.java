package com.simplilearn.unittesting;


public class DropdownValues {
	
	private String dropDownValue;

	public String getDropDownValue() {
		return dropDownValue;
	}

	public void setDropDownValue(String dropDownValue) {
		this.dropDownValue = dropDownValue;
	}
	
	

}
