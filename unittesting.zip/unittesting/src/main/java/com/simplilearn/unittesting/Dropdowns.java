package com.simplilearn.unittesting;

import java.util.List;

public class Dropdowns {
	
	private String dropDownName;
	private List<DropdownValues> dropDownValues;

	public String getDropDownName() {
		return dropDownName;
	}

	public void setDropDownName(String dropDownName) {
		this.dropDownName = dropDownName;
	}

	public List<DropdownValues> getDropDownValues() {
		return dropDownValues;
	}

	public void setDropDownValues(List<DropdownValues> dropDownValues) {
		this.dropDownValues = dropDownValues;
	}
	
}
